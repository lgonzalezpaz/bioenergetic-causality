"""
Identifiability analysis of causal direction in the coupled
excitability <-> bioenergetics loop.

Implements: parameter continuation, the inverse problem against human data,
phenotype matching, static and dynamic discriminators, the Bioenergetic
Causality Index (BCI), Monte-Carlo classification performance, closure-time
analysis and variance-based sensitivity analysis.
"""

import numpy as np
from scipy.optimize import brentq, least_squares
from scipy.stats import qmc, mannwhitneyu

import model as M

RNG = np.random.default_rng(20261102)

# ---------------------------------------------------------------------------
# Human reference data (literature-derived quantitative validation set, LQVS)
# Every entry is a published central estimate; see REFS for provenance.
# ---------------------------------------------------------------------------
LQVS = [
    dict(key="C1_act", label="Complex I activity (ASD/control)", value=4.4 / 12.0,
         lo=2.8 / 16.0, hi=6.0 / 8.0, src="Giulivi 2010 JAMA 304:2389 "
         "(NADH oxidase, citrate-synthase normalised; 95% CI 2.8-6.0 vs 8-16)"),
    dict(key="ROS", label="Mitochondrial H2O2 production (ASD/control)",
         value=0.34 / 0.16, lo=0.26 / 0.20, hi=0.42 / 0.12,
         src="Giulivi 2010 JAMA 304:2389 (complex III, nmol/min/mg)"),
    dict(key="mtDNA", label="mtDNA copy number (ASD/control)", value=239 / 179,
         lo=217 / 193, hi=239 / 165, src="Giulivi 2010 JAMA 304:2389"),
    dict(key="PDH", label="Pyruvate dehydrogenase activity (ASD/control)",
         value=1.0 / 2.3, lo=0.6 / 2.9, hi=1.4 / 1.7,
         src="Giulivi 2010 JAMA 304:2389"),
    dict(key="pyruvate", label="Plasma pyruvate (ASD/control)", value=0.23 / 0.08,
         lo=0.15 / 0.12, hi=0.31 / 0.04, src="Giulivi 2010 JAMA 304:2389"),
    dict(key="C1_cortex", label="Complex I activity, frontal cortex (ASD/control)",
         value=0.69, lo=0.60, hi=0.78,
         src="Gu et al. 2013 Transl Psychiatry 3:e299 (31% reduction)"),
    dict(key="C5_cortex", label="Complex V activity, frontal cortex (ASD/control)",
         value=0.64, lo=0.55, hi=0.73,
         src="Gu et al. 2013 Transl Psychiatry 3:e299 (36% reduction)"),
    dict(key="mito_mass", label="Mitochondrial membrane mass (ASD/control)",
         value=1.30, lo=1.10, hi=1.60,
         src="Tang et al. 2013 Neurobiol Dis 54:349 (Tom20/Tim23/porin elevated)"),
    dict(key="firing", label="Cortical E/I conductance ratio (ASD/control)",
         value=1.50, lo=1.20, hi=1.90,
         src="Antoine et al. 2019 Neuron 101:648 (increased E-I conductance "
             "ratio across four ASD mouse models, with normalised spiking)"),
]
LQVS_PRIMARY = ["C1_act", "ROS", "mtDNA"]   # the adjudicating triplet


# ---------------------------------------------------------------------------
# Observable map: model state -> measurable quantity (ratio to control)
# ---------------------------------------------------------------------------
def observables(y, p, p0, y0):
    """Map a steady state onto the ratios reported in human studies."""
    _, fl = M.fluxes(y, p)
    _, fl0 = M.fluxes(y0, p0)
    c1_act = (1.0 - p["lam_M"]) * y[8]          # measured complex I activity
    # Mitochondrial biogenesis proxy: compensatory response to the chronic
    # energetic/oxidative load, taken as the relative F1F0 flux demand.
    mass = fl["J_F1"] / fl0["J_F1"]
    return dict(
        C1_act=c1_act / ((1.0 - p0["lam_M"]) * y0[8]),
        ROS=y[7] / y0[7],
        mtDNA=mass,
        mito_mass=mass,
        PDH=fl["J_DH"] / fl0["J_DH"],
        pyruvate=fl0["J_DH"] / max(fl["J_DH"], 1e-12),   # backed-up glycolytic flux
        C1_cortex=c1_act / ((1.0 - p0["lam_M"]) * y0[8]),
        C5_cortex=fl["J_F1"] / fl0["J_F1"] * (y[4] / y0[4]) ** 2,
        firing=y[0] / y0[0],
        ATP=y[6] / y0[6],
        Dpsi=y[4] / y0[4],
        NADH=y[5] / y0[5],
        Cam=y[3] / y0[3],
        lactate=fl0["J_F1"] / max(fl["J_F1"], 1e-12) * (y0[6] / y[6]),
    )


# ---------------------------------------------------------------------------
# Continuation
# ---------------------------------------------------------------------------
def continuation(p, mode, lams, damage_on, y_start=None):
    """Follow a branch of steady states, using each solution to seed the next."""
    y = p["_y0"] if y_start is None else y_start.copy()
    out = []
    for lam in lams:
        q = M.with_lesion(p, mode, lam, damage_on)
        try:
            y = M.steady_state(q, y, strict=False)
        except Exception:
            out.append(None)
            continue
        out.append(y.copy())
    return out


# ---------------------------------------------------------------------------
# Inverse problem: which lesion mode reproduces the human triplet?
# ---------------------------------------------------------------------------
def fit_mode_to_data(p_base, mode, keys=LQVS_PRIMARY, x0=None, verbose=False):
    """Fit (lesion severity, Ca2+ -> ROS gain) to the human observable triplet.

    b_Ca (the in vivo Ca2+ amplification of ROS emission) is not identified by
    resting data, so it is estimated jointly with the lesion severity rather
    than assumed. The residual is in log-ratio space.
    """
    tgt = {d["key"]: d["value"] for d in LQVS}
    lo = {d["key"]: d["lo"] for d in LQVS}
    hi = {d["key"]: d["hi"] for d in LQVS}
    # log-scale uncertainty from the reported interval
    sig = {k: max(abs(np.log(hi[k] / tgt[k])), abs(np.log(tgt[k] / lo[k]))) / 1.96
           for k in keys}

    def build(theta):
        lam, log_bca = theta
        import model as _M
        q0 = dict(_M.P0)
        q0["b_Ca"] = float(np.exp(log_bca))
        p0 = _recalibrate(q0)
        q = M.with_lesion(p0, mode, float(lam), damage_on=1.0)
        y = M.steady_state(q, p0["_y0"], strict=False)
        return observables(y, q, p0, p0["_y0"]), y, q, p0

    def resid(theta):
        try:
            obs, *_ = build(theta)
        except Exception:
            return np.full(len(keys), 10.0)
        r = [np.log(max(obs[k], 1e-9) / tgt[k]) / sig[k] for k in keys]
        return np.array(r)

    if x0 is None:
        x0 = [0.6, np.log(20.0)] if mode == "E" else [0.63, np.log(20.0)]
    sol = least_squares(resid, x0, bounds=([1e-3, np.log(1.0)],
                                           [3.0, np.log(200.0)]),
                        xtol=1e-10, ftol=1e-10)
    obs, y, q, p0 = build(sol.x)
    chi2 = float(np.sum(sol.fun ** 2))
    if verbose:
        print(f"  mode {mode}: lam={sol.x[0]:.4f} b_Ca={np.exp(sol.x[1]):.2f} "
              f"chi2={chi2:.3f}")
        for k in keys:
            print(f"     {k:<10s} model {obs[k]:.3f}  data {tgt[k]:.3f}")
    return dict(mode=mode, lam=float(sol.x[0]), b_Ca=float(np.exp(sol.x[1])),
                chi2=chi2, obs=obs, y=y, p=q, p_base=p0,
                resid={k: float(v) for k, v in zip(keys, sol.fun)})


def _recalibrate(pdict):
    """Recalibrate the model after changing a structural parameter."""
    import model as _M
    saved = dict(_M.P0)
    try:
        _M.P0.update(pdict)
        return _M.calibrate(verbose=False)
    finally:
        _M.P0.clear()
        _M.P0.update(saved)


# ---------------------------------------------------------------------------
# Phenotype matching on the measured complex I activity
# ---------------------------------------------------------------------------
def match_on_complexI(p, target_act=4.4 / 12.0, bracket_M=(0.01, 0.95),
                      bracket_E=(0.01, 2.0), n_scan=22):
    """Titrate each lesion mode to the SAME measured complex I activity.

    This is the clinically realised matching: two patients presenting with
    identical biochemistry, one whose lesion is structural (Mode M) and one in
    whom the same deficit was produced by ROS-mediated inactivation downstream
    of excess activity (Mode E).
    """
    y0, out = p["_y0"], {}
    ref = (1.0 - p["lam_M"]) * y0[8]

    def act(mode, lam, seed=None, fast=True):
        q = M.with_lesion(p, mode, lam, damage_on=1.0)
        y = M.steady_state(q, y0 if seed is None else seed, strict=False,
                           fast=fast)
        return (1.0 - q["lam_M"]) * y[8] / ref, y, q

    for mode, br in (("M", bracket_M), ("E", bracket_E)):
        # Continuation-seeded coarse scan: each solve starts from the previous
        # solution, which both accelerates and stabilises branch following.
        grid = np.linspace(br[0], br[1], n_scan)
        vals, seed = [], None
        for g in grid:
            a_, y_, _ = act(mode, g, seed)
            vals.append(a_ - target_act)
            seed = y_
        vals = np.array(vals)
        f = lambda l: act(mode, l)[0] - target_act
        sgn = np.where(np.sign(vals[:-1]) * np.sign(vals[1:]) < 0)[0]
        if len(sgn) == 0:
            k = int(np.argmin(np.abs(vals)))
            lam = float(grid[k])
        else:
            i = sgn[0]
            lam = float(brentq(f, grid[i], grid[i + 1], xtol=1e-10))
        a, y, q = act(mode, lam, fast=False)
        out[mode] = dict(lam=lam, act=float(a), y=y, p=q)
    return out


# ---------------------------------------------------------------------------
# Discriminator 1: open-loop gain asymmetry from the Jacobian
# ---------------------------------------------------------------------------
E_IDX = [0, 1, 2]              # electrical / cytosolic node
M_IDX = [3, 4, 5, 6, 7, 8, 9]  # mitochondrial node


def loop_gains(y, p):
    """Open-loop DC gains of each arm of the loop, from the Jacobian.

    Partitioning J into electrical (E) and metabolic (M) blocks,
        G_ME = -A_EE^-1 A_EM   (metabolic state -> electrical state)
        G_EM = -A_MM^-1 A_ME   (electrical state -> metabolic state)
    Gains are made dimensionless by scaling each state by its control value.
    """
    J = M.jacobian(y, p)
    s = np.maximum(np.abs(p["_y0"]), 1e-9)
    J = J * s[None, :] / s[:, None]          # scale to relative coordinates
    # Drop states that are frozen (identically zero row), which occurs when the
    # slow proteostatic loop is held fixed for an acute probe.
    m_idx = [i for i in M_IDX if np.any(np.abs(J[i, :]) > 1e-12)]
    A_EE = J[np.ix_(E_IDX, E_IDX)]
    A_EM = J[np.ix_(E_IDX, m_idx)]
    A_ME = J[np.ix_(m_idx, E_IDX)]
    A_MM = J[np.ix_(m_idx, m_idx)]
    G_ME = -np.linalg.pinv(A_EE) @ A_EM
    G_EM = -np.linalg.pinv(A_MM) @ A_ME
    g_me = float(np.linalg.norm(G_ME, 2))
    g_em = float(np.linalg.norm(G_EM, 2))
    loop = float(np.linalg.norm(G_ME @ G_EM, 2))
    # Sign convention fixed a priori from mechanism: a lesion at the metabolic
    # node drives that node toward its capacity limit, so metabolic
    # fluctuations propagate to the electrical node with higher incremental
    # gain. gamma > 0 therefore predicts a primary metabolic lesion.
    gamma = float(np.log10((g_me + 1e-12) / (g_em + 1e-12)))
    return dict(g_me=g_me, g_em=g_em, loop=loop, gamma=gamma)


# ---------------------------------------------------------------------------
# Discriminator 2: perturbation asymmetry index
# ---------------------------------------------------------------------------
def recovery_time(y, p):
    """Linear relaxation time of the slowest mode, tau_rec = -1/max Re(lambda).

    Loss of resilience inflates tau_rec: this is the critical-slowing-down
    early-warning signal, and unlike the loop gain it is directly measurable
    as the recovery rate following a small perturbation.
    """
    J = M.jacobian(y, p)
    keep = [i for i in range(J.shape[0]) if np.any(np.abs(J[i, :]) > 1e-12)]
    ev = np.linalg.eigvals(J[np.ix_(keep, keep)]).real
    lam_max = float(ev.max())
    # Censor the relaxation time at TAU_CAP_FACTOR times the slowest physical
    # relaxation in the model. Marginally stable operating points would
    # otherwise return an infinite value and inflate the variance of any
    # downstream statistic without carrying extra information.
    tau_cap = TAU_CAP_FACTOR * p["tau_c1"]
    if lam_max < -1.0 / tau_cap:
        tau = float(-1.0 / lam_max)
    else:
        tau = float(tau_cap)
    return tau, lam_max


def stress(y, y0):
    """Scalar cellular-stress deviation: relative ATP loss plus ROS excess."""
    return abs(y[6] / y0[6] - 1.0) + abs(y[7] / y0[7] - 1.0)


def perturbation_asymmetry(p_les, y_les, p, block=0.5, rescue=1.0):
    """PAI > 0: metabolic support relieves more than electrical silencing
    (signature of a primary metabolic lesion). PAI < 0: the converse.

    Both interventions are applied acutely, with the slow proteostatic
    variables frozen at their chronic values, so the comparison is of
    equal-duration, equal-nature probes.
    """
    y0 = p["_y0"]
    base = dict(p_les)
    base["damage_on"] = 0.0
    yb = M.steady_state(base, y_les, strict=False)
    S0 = stress(yb, y0)

    qE = dict(base); qE["blockNa"] = block
    qM = dict(base); qM["rescue"] = rescue
    yE = M.steady_state(qE, yb, strict=False)
    yM = M.steady_state(qM, yb, strict=False)
    rho_E = (S0 - stress(yE, y0)) / max(S0, 1e-9)
    rho_M = (S0 - stress(yM, y0)) / max(S0, 1e-9)
    pai = (rho_M - rho_E) / (abs(rho_M) + abs(rho_E) + 1e-9)
    return dict(rho_E=float(rho_E), rho_M=float(rho_M), pai=float(pai),
                S0=float(S0))


# ---------------------------------------------------------------------------
# Discriminator 3: directed information flow in the stochastic loop
# ---------------------------------------------------------------------------
def simulate_sde(p, y_init, T=600.0, dt=0.005, sample_dt=0.1, n_rep=16,
                 sig_E=0.045, sig_M=0.045, seed=0):
    """Euler-Maruyama simulation with noise injected at BOTH nodes.

    Matched noise amplitudes at the electrical node (excitatory drive) and the
    metabolic node (substrate supply) are essential: an asymmetry in directed
    information that merely reflected where noise was injected would carry no
    causal information.
    """
    rng = np.random.default_rng(seed)
    n_steps = int(round(T / dt))
    stride = max(1, int(round(sample_dt / dt)))
    y = np.repeat(np.asarray(y_init, float)[:, None], n_rep, axis=1)
    q = dict(p)
    rec = []
    sq = np.sqrt(dt)
    xE = np.zeros(n_rep)
    xM = np.zeros(n_rep)
    tau_ou = 1.0
    for i in range(n_steps):
        # Ornstein-Uhlenbeck fluctuations, identical statistics at both nodes
        xE += (-xE / tau_ou) * dt + sig_E * np.sqrt(2.0 / tau_ou) * sq * rng.standard_normal(n_rep)
        xM += (-xM / tau_ou) * dt + sig_M * np.sqrt(2.0 / tau_ou) * sq * rng.standard_normal(n_rep)
        q["lam_E"] = p["lam_E"] + xE
        q["S_sub"] = p["S_sub"] * (1.0 + xM)
        dy, _ = M.fluxes(y, q)
        y = y + dy * dt
        y[1] = np.maximum(y[1], 1e-6); y[2] = np.maximum(y[2], 1e-9)
        y[3] = np.maximum(y[3], 1e-9); y[4] = np.clip(y[4], 1.0, 260.0)
        y[5] = np.clip(y[5], 1e-6, M.NAD_TOT - 1e-6)
        y[6] = np.clip(y[6], 1e-6, M.A_TOT - 1e-6)
        y[7] = np.maximum(y[7], 0.0)
        y[8] = np.clip(y[8], 1e-4, 1.0); y[9] = np.clip(y[9], 1e-4, 1.0)
        if i % stride == 0:
            rec.append(y.copy())
    arr = np.asarray(rec)                     # (n_samp, 10, n_rep)
    burn = int(0.25 * arr.shape[0])
    return arr[burn:]


def _symbolise(x, nbins):
    q = np.quantile(x, np.linspace(0, 1, nbins + 1)[1:-1])
    return np.searchsorted(q, x)


def transfer_entropy(src, dst, nbins=5, lag=1):
    """Binned transfer entropy TE(src -> dst) with k = l = 1, in bits."""
    s = _symbolise(src, nbins)[:-lag]
    d0 = _symbolise(dst, nbins)[:-lag]
    d1 = _symbolise(dst, nbins)[lag:]
    n = len(s)
    idx = (d1 * nbins + d0) * nbins + s
    cnt = np.bincount(idx, minlength=nbins ** 3).reshape(nbins, nbins, nbins)
    p_abc = cnt / n
    p_bc = p_abc.sum(axis=0)
    p_ab = p_abc.sum(axis=2)
    p_b = p_abc.sum(axis=(0, 2))
    with np.errstate(divide="ignore", invalid="ignore"):
        term = p_abc * np.log2((p_abc * p_b[None, :, None])
                               / (p_ab[:, :, None] * p_bc[None, :, :]))
    return float(np.nansum(term[np.isfinite(term)]))


def directed_flow(arr, i_metab=4, i_elec=0, nbins=5, n_surr=40, seed=1):
    """Net directed information between the metabolic and electrical nodes,
    corrected by a block-shuffled surrogate distribution."""
    rng = np.random.default_rng(seed)
    te_me, te_em, lags = [], [], []
    n_rep = arr.shape[2]
    for k in range(n_rep):
        m = arr[:, i_metab, k]
        e = arr[:, i_elec, k]
        m = (m - m.mean()) / (m.std() + 1e-12)
        e = (e - e.mean()) / (e.std() + 1e-12)
        raw_me = transfer_entropy(m, e, nbins)
        raw_em = transfer_entropy(e, m, nbins)
        s_me, s_em = [], []
        for _ in range(n_surr):
            sh = rng.permutation(len(m))
            s_me.append(transfer_entropy(m[sh], e, nbins))
            s_em.append(transfer_entropy(e[sh], m, nbins))
        te_me.append(raw_me - np.mean(s_me))
        te_em.append(raw_em - np.mean(s_em))
        # lead/lag of the peak cross-correlation (positive = metabolism leads)
        nl = 60
        cc = [np.corrcoef(m[nl + L:len(m) - nl + L], e[nl:len(e) - nl])[0, 1]
              for L in range(-nl, nl + 1)]
        lags.append(-(np.argmax(np.abs(cc)) - nl))
    te_me = np.array(te_me); te_em = np.array(te_em); lags = np.array(lags)
    denom = np.abs(te_me) + np.abs(te_em) + 1e-12
    return dict(te_me=te_me, te_em=te_em, lag=lags,
                te_me_mean=float(te_me.mean()), te_em_mean=float(te_em.mean()),
                asym=float(np.mean((te_me - te_em) / denom)),
                asym_sd=float(np.std((te_me - te_em) / denom)),
                lag_mean=float(lags.mean()))


# ---------------------------------------------------------------------------
# Composite index
# ---------------------------------------------------------------------------
GAMMA_0 = 1.0
TAU_CAP_FACTOR = 100.0


def bci(Lambda, pai, Theta, lag=None, lag0=5.0):
    """Bioenergetic Causality Index. Positive -> primary metabolic lesion.

    Lambda  log10 closed-loop gain at the lesioned operating point
    pai     perturbation asymmetry index
    Theta   log10 (recovery time / control recovery time)

    Weights are fixed a priori at 1/n and are NOT fitted to the mode labels,
    so the reported classification performance is not circular.
    """
    terms = [np.tanh(Lambda / GAMMA_0), pai, np.tanh(Theta / GAMMA_0)]
    if lag is not None:
        terms.append(np.tanh(lag / lag0))
    return float(np.mean(terms))
