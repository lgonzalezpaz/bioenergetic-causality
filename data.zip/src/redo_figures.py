"""Regenerate all manuscript figures from results/results.json with corrected
layout. Figure 3 additionally re-runs the stochastic simulation, whose raw
traces are not stored in the results file."""

import json
import os

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import gridspec

import model as M
import analysis as A
from run_all import (save, FIG, RES, C_M, C_E, C_K, C_D, acute,
                     discriminators, SEED)

R = json.load(open(os.path.join(RES, "results.json")))
inv, mt, df = R["inverse"], R["matched"], R["directed_flow"]
mc, ctrl, sep = R["monte_carlo"], R["control"], R["matched"]["separation_sigma"]
dynM, dynE = mt["dynamic"]["M"], mt["dynamic"]["E"]
cont, clos = R["continuation"], R["closure"]
tgt = {d["key"]: d for d in A.LQVS}


def tag(ax, letter):
    """Panel letter placed clear of the axes title."""
    ax.text(-0.30, 1.21, letter, transform=ax.transAxes, fontsize=10,
            fontweight="bold", va="top", ha="left")


def title(ax, text):
    ax.set_title(text, fontsize=7.4, pad=8)


def arr(key, field):
    rows = [r for r in cont[key] if r is not None]
    return (np.array([r["lam"] for r in rows]),
            np.array([r[field] for r in rows]))


# ---------------------------------------------------------------- figure 1
fig = plt.figure(figsize=(7.1, 5.0))
gs = gridspec.GridSpec(2, 3, figure=fig, hspace=0.62, wspace=0.46)
panels = [("ATP", "ATP / control"), ("ROS", "H$_2$O$_2$ / control"),
          ("C1_act", "complex I act. / control"),
          ("Dpsi", r"$|\Delta\psi_m|$ / control"),
          ("Cam", r"matrix Ca$^{2+}$ / control"),
          ("firing", "firing rate / control")]
for i, (fl, lab) in enumerate(panels):
    ax = fig.add_subplot(gs[i // 3, i % 3])
    for mode, c in (("M", C_M), ("E", C_E)):
        x, v = arr(f"{mode}_1", fl)
        ax.plot(x, v, color=c, label=f"Mode {mode}")
        x2, v2 = arr(f"{mode}_0", fl)
        ax.plot(x2, v2, color=c, ls=":", lw=1.0, alpha=0.85)
    ax.axhline(1.0, color=C_K, lw=0.6, ls="--")
    ax.set_xlabel(r"lesion severity $\lambda$")
    ax.set_ylabel(lab, fontsize=7.4)
    tag(ax, "abcdef"[i])
    if i == 0:
        ax.legend(loc="lower left", fontsize=6.6)
fig.suptitle("Figure 1   Dose–response of the coupled loop to a lesion at the "
             "metabolic (M) or electrical (E) node\n"
             "solid, slow proteostatic loop active;  dotted, loop frozen",
             fontsize=8.4, y=1.03)
save(fig, "figure1_continuation")

# ---------------------------------------------------------------- figure 2
fig = plt.figure(figsize=(7.1, 3.3))
gs = gridspec.GridSpec(1, 2, figure=fig, wspace=0.42, width_ratios=[1.4, 1.0])
ax = fig.add_subplot(gs[0, 0])
keys = A.LQVS_PRIMARY + ["PDH", "pyruvate", "mito_mass", "firing"]
xp = np.arange(len(keys))
for i, k in enumerate(keys):
    d = tgt[k]
    ax.plot([i, i], [d["lo"], d["hi"]], color=C_D, lw=5, alpha=0.28,
            solid_capstyle="butt")
    ax.plot(i, d["value"], "D", color=C_D, ms=5,
            label="human data" if i == 0 else None)
for mode, c, mk in (("M", C_M, "o"), ("E", C_E, "s")):
    ax.plot(xp, [inv[mode]["obs"][k] for k in keys], mk, color=c, ms=5.5,
            mfc="none", mew=1.5, ls="none", label=f"Mode {mode} best fit")
ax.axhline(1.0, color=C_K, lw=0.6, ls="--")
ax.set_yscale("log")
ax.set_xticks(xp)
ax.set_xticklabels(["complex I", "H$_2$O$_2$", "mtDNA", "PDH", "pyruvate",
                    "mito mass", "E/I ratio"], rotation=40, ha="right")
ax.set_ylabel("ratio to control")
ax.legend(loc="upper left", fontsize=6.8)
tag(ax, "a")
title(ax, "Only an electrical lesion fits the data")

ax = fig.add_subplot(gs[0, 1])
lab = A.LQVS_PRIMARY
w = 0.36
for j, (mode, c) in enumerate((("M", C_M), ("E", C_E))):
    ax.bar(np.arange(len(lab)) + (j - 0.5) * w,
           [inv[mode]["resid"][k] for k in lab], w, color=c,
           label=f"Mode {mode}")
ax.axhline(0, color=C_K, lw=0.7)
for s in (-1.96, 1.96):
    ax.axhline(s, color=C_K, lw=0.6, ls=":")
ax.set_xticks(np.arange(len(lab)))
ax.set_xticklabels(["complex I", "H$_2$O$_2$", "mtDNA"], rotation=40,
                   ha="right")
ax.set_ylabel(r"standardised residual ($\sigma$)")
ax.legend(fontsize=6.8)
tag(ax, "b")
title(ax, f"$\\chi^2$:  M = {inv['M']['chi2']:.0f},   E = "
          f"{inv['E']['chi2']:.2f}")
fig.suptitle("Figure 2   Adjudication of causal direction by joint inversion "
             "of three human observables", fontsize=8.4, y=1.12)
save(fig, "figure2_inverse_problem")

# ---------------------------------------------------------------- figure 3
print("re-running stochastic simulation for figure 3 ...")
p = M.calibrate(verbose=False)
mm = A.match_on_complexI(p, target_act=mt["target_complexI"])
sde = {}
for mode in ("M", "E"):
    q, ya = acute(mm[mode]["p"], mm[mode]["y"])
    a3 = A.simulate_sde(q, ya, T=600.0, dt=0.005, sample_dt=0.25, n_rep=4,
                        seed=SEED + (mode == "E"))
    sde[mode] = a3[:, :, 0]

fig = plt.figure(figsize=(7.1, 5.1))
gs = gridspec.GridSpec(2, 3, figure=fig, hspace=0.74, wspace=0.58)
for j, mode in enumerate(("M", "E")):
    ax = fig.add_subplot(gs[0, j])
    tr = sde[mode]
    t = np.arange(tr.shape[0]) * 0.25
    z = lambda v: (v - v.mean()) / (v.std() + 1e-12)
    ax.plot(t, z(tr[:, 4]) + 4.5, color="#4a4a8c", lw=0.75,
            label=r"$|\Delta\psi_m|$")
    ax.plot(t, z(tr[:, 0]) - 3.0, color=(C_M if mode == "M" else C_E),
            lw=0.75, label="firing rate")
    ax.set_xlim(t[0], t[0] + 200)
    ax.set_yticks([])
    ax.set_xlabel("time (s)")
    title(ax, f"Mode {mode} fluctuations")
    tag(ax, "ab"[j])
    if j == 0:
        ax.legend(loc="center right", fontsize=6.4)

ax = fig.add_subplot(gs[0, 2])
w = 0.34
for j, mode in enumerate(("M", "E")):
    fl = df[mode]
    ax.bar(j - w / 2, fl["te_me_mean"] * 1e3, w, color="#4a4a8c",
           label=r"$\Delta\psi_m\!\rightarrow$ rate" if j == 0 else None)
    ax.bar(j + w / 2, fl["te_em_mean"] * 1e3, w, color="#b08a3c",
           label=r"rate $\rightarrow \Delta\psi_m$" if j == 0 else None)
ax.axhline(0, color=C_K, lw=0.7)
ax.set_xticks([0, 1]); ax.set_xticklabels(["Mode M", "Mode E"])
ax.set_ylabel("effective TE (millibits)", fontsize=7.4)
ax.legend(loc="upper right", fontsize=6.4)
title(ax, f"Directed flow ($P$ = {df['mannwhitney_p']:.0e})")
tag(ax, "c")

ax = fig.add_subplot(gs[1, 0])
for j, mode in enumerate(("M", "E")):
    d = mt["dynamic"][mode]
    ax.bar(j - w / 2, d["rho_M"], w, color="#117733",
           label="metabolic support" if j == 0 else None)
    ax.bar(j + w / 2, d["rho_E"], w, color="#882255",
           label="electrical silencing" if j == 0 else None)
ax.axhline(0, color=C_K, lw=0.7)
ax.set_yscale("symlog", linthresh=1.0)
ax.set_yticks([-10, -1, 0, 1])
ax.set_yticklabels(["-10", "-1", "0", "1"])
ax.set_xticks([0, 1]); ax.set_xticklabels(["Mode M", "Mode E"])
ax.set_ylabel("fraction of stress relieved", fontsize=7.4)
ax.legend(loc="upper right", fontsize=6.0)
ax.text(1 - w / 2, dynE["rho_M"] * 0.42, f"{dynE['rho_M']:.1f}",
        fontsize=6.2, color="white", ha="center", va="center",
        fontweight="bold")
title(ax, "Rescue asymmetry")
tag(ax, "d")

ax = fig.add_subplot(gs[1, 1])
names = [r"$\Lambda$", "PAI", r"$\Theta$", "BCI"]
kk = ["Lambda", "PAI", "Theta", "BCI"]
xx = np.arange(len(names))
for j, (mode, c) in enumerate((("M", C_M), ("E", C_E))):
    ax.bar(xx + (j - 0.5) * w, [mt["dynamic"][mode][k] for k in kk], w,
           color=c, label=f"Mode {mode}")
ax.axhline(0, color=C_K, lw=0.7)
ax.set_xticks(xx); ax.set_xticklabels(names)
ax.set_ylabel("discriminator value", fontsize=7.4)
ax.legend(fontsize=6.4)
title(ax, "Discriminators")
tag(ax, "e")

ax = fig.add_subplot(gs[1, 2])
pretty = {"C1_act": "complex I", "ROS": "H$_2$O$_2$", "mtDNA": "mtDNA",
          "PDH": "PDH", "pyruvate": "pyruvate"}
ks = [k for k in ["C1_act", "PDH", "pyruvate", "mtDNA", "ROS"] if k in sep]
xx = np.arange(len(ks))
ax.bar(xx, [sep[k] for k in ks], 0.6,
       color=["#9a9a9a" if sep[k] < 1.96 else "#cc3311" for k in ks])
ax.axhline(1.96, color="#cc3311", lw=0.9, ls="--", label="$P<0.05$")
ax.set_xticks(xx)
ax.set_xticklabels([pretty[k] for k in ks], rotation=40, ha="right")
ax.set_ylabel(r"mode separation ($\sigma$)", fontsize=7.4)
ax.legend(loc="upper left", fontsize=6.4)
title(ax, "Static marker separation")
tag(ax, "f")
fig.suptitle("Figure 3   Phenotype-matched lesions are separated by loop "
             "dynamics but not by steady-state biochemistry",
             fontsize=8.4, y=1.02)
save(fig, "figure3_discriminators")

# ---------------------------------------------------------------- figure 4
fig = plt.figure(figsize=(7.1, 2.9))
gs = gridspec.GridSpec(1, 3, figure=fig, wspace=0.50)
ax = fig.add_subplot(gs[0, 0])
for mode, c in (("M", C_M), ("E", C_E)):
    s = clos[mode]
    ax.semilogx([v["t"] for v in s], [v["C1"] for v in s], color=c,
                label=f"Mode {mode}")
    ax.semilogx([v["t"] for v in s], [v["ROS"] for v in s], color=c, ls="--",
                lw=1.0)
ax.axhline(mt["target_complexI"], color=C_D, lw=0.9, ls=":")
ax.set_xlabel("time since onset (s)")
ax.set_ylabel("ratio to control", fontsize=7.4)
ax.legend(fontsize=6.6)
title(ax, "Biochemistry converges")
tag(ax, "a")
ax = fig.add_subplot(gs[0, 1])
for mode, c in (("M", C_M), ("E", C_E)):
    s = clos[mode]
    ax.semilogx([v["t"] for v in s], [v["BCI"] for v in s], color=c,
                label=f"Mode {mode}")
ax.axhline(0, color=C_K, lw=0.7)
ax.set_xlabel("time since onset (s)")
ax.set_ylabel("BCI", fontsize=7.4)
ax.legend(fontsize=6.6)
title(ax, "Signature persists")
tag(ax, "b")
ax = fig.add_subplot(gs[0, 2])
tt = np.array([s["t"] for s in clos["M"]])
gap = np.abs(np.array([s["BCI"] for s in clos["M"]])
             - np.array([s["BCI"] for s in clos["E"]]))
ax.semilogx(tt, gap, color="#333333")
ax.axvline(R["closure_time_s"], color="#cc3311", lw=0.9, ls="--")
ax.set_xlabel("time since onset (s)")
ax.set_ylabel(r"$|\mathrm{BCI}_M-\mathrm{BCI}_E|$", fontsize=7.4)
title(ax, "Inferential window")
tag(ax, "c")
fig.suptitle("Figure 4   Static phenotypes converge while the loop retains a "
             "directional signature", fontsize=8.4, y=1.09)
save(fig, "figure4_closure")

# ---------------------------------------------------------------- figure 5
rows = mc["rows"]
lab = np.array([1 if r["mode"] == "M" else 0 for r in rows])
F = np.array([[r["Lambda"], r["PAI"], r["Theta"]] for r in rows])
bci = np.array([r["BCI"] for r in rows])
rng = np.random.default_rng(SEED)
idx = rng.permutation(len(rows)); h = len(idx) // 2
tr_i, te_i = idx[:h], idx[h:]
signs = np.array(mc["signs"])


def roc(s, l):
    o = np.argsort(-s); l = l[o]
    tp = np.cumsum(l); fp = np.cumsum(1 - l)
    tpr = np.r_[0, tp / max(l.sum(), 1)]
    fpr = np.r_[0, fp / max((1 - l).sum(), 1)]
    return fpr, tpr, float(np.trapezoid(tpr, fpr))


mu, sd = F[tr_i].mean(0), F[tr_i].std(0) + 1e-12
f1, t1, _ = roc((((F[te_i] - mu) / sd) * signs).mean(1), lab[te_i])
f2, t2, _ = roc(bci[te_i], lab[te_i])
fig = plt.figure(figsize=(7.1, 2.8))
gs = gridspec.GridSpec(1, 3, figure=fig, wspace=0.50)
ax = fig.add_subplot(gs[0, 0])
ax.plot(f1, t1, color="#1b4f9c",
        label=f"composite (AUC {mc['auc_composite_heldout']:.3f})")
ax.plot(f2, t2, color="#c2541a", ls="--",
        label=f"BCI, fixed weights ({mc['auc_bci_heldout']:.3f})")
ax.plot([0, 1], [0, 1], color=C_K, lw=0.7, ls=":")
ax.set_xlabel("false-positive rate"); ax.set_ylabel("true-positive rate",
                                                    fontsize=7.4)
ax.legend(loc="lower right", fontsize=6.4)
title(ax, "Held-out ROC")
tag(ax, "a")
ax = fig.add_subplot(gs[0, 1])
bins = np.linspace(min(bci.min(), -1), max(bci.max(), 1), 26)
ax.hist(bci[lab == 1], bins=bins, color=C_M, alpha=0.72, label="Mode M")
ax.hist(bci[lab == 0], bins=bins, color=C_E, alpha=0.72, label="Mode E")
ax.axvline(0, color=C_K, lw=0.8, ls="--")
ax.set_xlabel("BCI"); ax.set_ylabel("parameter draws", fontsize=7.4)
ax.legend(fontsize=6.6)
title(ax, f"$P$ = {mc['mannwhitney_p']:.0e},  $n$ = {mc['n_samples']}")
tag(ax, "b")
ax = fig.add_subplot(gs[0, 2])
nm = ["Lambda", "PAI", "Theta"]
ax.barh(np.arange(3), [mc["auc_single"][k] for k in nm], 0.55,
        color=["#9a9a9a", "#cc3311", "#9a9a9a"])
ax.axvline(0.5, color=C_K, lw=0.7, ls=":")
ax.set_yticks(np.arange(3))
ax.set_yticklabels([r"$\Lambda$", "PAI", r"$\Theta$"])
ax.set_xlim(0.4, 1.0); ax.set_xlabel("held-out AUC")
title(ax, "Single-discriminator AUC")
tag(ax, "c")
fig.suptitle("Figure 5   Robustness of causal classification to parameter "
             "uncertainty", fontsize=8.4, y=1.09)
save(fig, "figure5_roc")
print("all figures regenerated")
