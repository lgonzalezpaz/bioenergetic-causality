"""
Driver: reproduces every numerical result, figure and table in the manuscript.

Usage:  python run_all.py [--quick]

Outputs are written to ../results (JSON + CSV tables) and ../figures (PDF+PNG).
"""

import argparse
import json
import os
import platform
import sys
import time

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import gridspec
from scipy.stats import qmc, mannwhitneyu
from scipy.integrate import solve_ivp

import model as M
import analysis as A

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "..", "results")
FIG = os.path.join(HERE, "..", "figures")
os.makedirs(RES, exist_ok=True)
os.makedirs(FIG, exist_ok=True)

SEED = 20261102
rng = np.random.default_rng(SEED)
R = {}          # results dictionary

# ---- figure style ---------------------------------------------------------
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 8,
    "axes.labelsize": 8, "axes.titlesize": 8.5, "axes.titleweight": "bold",
    "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 7,
    "axes.linewidth": 0.7, "xtick.major.width": 0.7, "ytick.major.width": 0.7,
    "lines.linewidth": 1.3, "axes.spines.top": False, "axes.spines.right": False,
    "figure.dpi": 160, "savefig.dpi": 400, "savefig.bbox": "tight",
    "legend.frameon": False, "axes.grid": True, "grid.alpha": 0.18,
    "grid.linewidth": 0.5,
})
# Colour-blind-safe, legible in greyscale
C_M = "#1b4f9c"      # Mode M  (primary metabolic)
C_E = "#c2541a"      # Mode E  (primary electrical)
C_K = "#444444"      # control
C_D = "#117733"      # data


def save(fig, name):
    for ext in ("pdf", "png"):
        fig.savefig(os.path.join(FIG, f"{name}.{ext}"))
    plt.close(fig)
    print(f"    wrote figures/{name}.pdf|png")


def tag(ax, letter):
    ax.text(-0.17, 1.06, letter, transform=ax.transAxes,
            fontsize=10, fontweight="bold", va="bottom", ha="left")


def acute(p_les, y_les):
    """Freeze the slow proteostatic variables at their chronic values."""
    q = dict(p_les)
    q["damage_on"] = 0.0
    y = M.steady_state(q, y_les, strict=False)
    return q, y


def discriminators(p_les, y_les, p, tau0):
    q, ya = acute(p_les, y_les)
    g = A.loop_gains(ya, q)
    tau, lam_max = A.recovery_time(ya, q)
    pa = A.perturbation_asymmetry(p_les, y_les, p)
    Lam = float(np.log10(max(g["loop"], 1e-12)))
    Th = float(np.log10(tau0 / max(tau, 1e-12)))      # >0 : faster relaxation
    return dict(Lambda=Lam, Theta=Th, PAI=pa["pai"], rho_E=pa["rho_E"],
                rho_M=pa["rho_M"], loop=g["loop"], g_me=g["g_me"],
                g_em=g["g_em"], tau=tau, lam_max=lam_max,
                BCI=A.bci(Lam, pa["pai"], Th))


def main(quick=False):
    t_start = time.time()
    NS = dict(cont=46, mc=160, sobol=24, sde_T=1200.0, sde_rep=16, clos=18)
    if quick:
        NS = dict(cont=18, mc=40, sobol=8, sde_T=120.0, sde_rep=4, clos=8)

    # =====================================================================
    print("[1] calibration")
    p = M.calibrate(verbose=True)
    y0 = p["_y0"]
    q0a, y0a = acute(p, y0)
    tau0, _ = A.recovery_time(y0a, q0a)
    _, fl0 = M.fluxes(y0, p)
    R["control"] = dict(
        state={n: float(v) for n, v in zip(M.STATE_NAMES, y0)},
        fluxes={k: float(np.asarray(v)) for k, v in fl0.items()
                if np.ndim(v) == 0 or np.size(v) == 1},
        max_re_eig=p["_lam_max"], tau_rec_acute=tau0,
        params={k: float(p[k]) for k in M.P0 if not k.startswith("_")},
        calibrated={k: float(p[k]) for k in M.CALIB_KEYS},
    )
    print(f"    acute control relaxation time tau0 = {tau0:.1f} s")

    # =====================================================================
    print("[2] parameter continuation of both lesion branches")
    lamM = np.linspace(0.0, 0.90, NS["cont"])
    lamE = np.linspace(0.0, 1.60, NS["cont"])
    cont = {}
    for mode, lams in (("M", lamM), ("E", lamE)):
        for dmg in (0.0, 1.0):
            ys = A.continuation(p, mode, lams, dmg)
            rows = []
            for lam, y in zip(lams, ys):
                if y is None:
                    rows.append(None); continue
                q = M.with_lesion(p, mode, lam, dmg)
                ob = A.observables(y, q, p, y0)
                rows.append(dict(lam=float(lam),
                                 **{k: float(v) for k, v in ob.items()}))
            cont[f"{mode}_{int(dmg)}"] = rows
    R["continuation"] = cont

    def arr(key, field):
        rows = [r for r in cont[key] if r is not None]
        return (np.array([r["lam"] for r in rows]),
                np.array([r[field] for r in rows]))

    fig = plt.figure(figsize=(7.1, 4.6))
    gs = gridspec.GridSpec(2, 3, figure=fig, hspace=0.46, wspace=0.36)
    panels = [("ATP", "ATP / control"), ("ROS", "H$_2$O$_2$ / control"),
              ("C1_act", "complex I activity / control"),
              ("Dpsi", r"$|\Delta\psi_m|$ / control"),
              ("Cam", r"matrix [Ca$^{2+}$] / control"),
              ("firing", "firing rate / control")]
    for i, (f, lab) in enumerate(panels):
        ax = fig.add_subplot(gs[i // 3, i % 3])
        for mode, c in (("M", C_M), ("E", C_E)):
            x, v = arr(f"{mode}_1", f)
            ax.plot(x, v, color=c, label=f"Mode {mode}")
            x2, v2 = arr(f"{mode}_0", f)
            ax.plot(x2, v2, color=c, ls=":", lw=1.0, alpha=0.85)
        ax.axhline(1.0, color=C_K, lw=0.6, ls="--")
        ax.set_xlabel(r"lesion severity $\lambda$")
        ax.set_ylabel(lab)
        tag(ax, "abcdef"[i])
        if i == 0:
            ax.legend(loc="lower left")
    fig.suptitle("Figure 1  Dose-response of the coupled loop to a lesion at the "
                 "metabolic (M) or electrical (E) node\n"
                 "solid: slow proteostatic loop active; dotted: loop frozen",
                 fontsize=8.5, y=1.04)
    save(fig, "figure1_continuation")

    # =====================================================================
    print("[3] inverse problem against the human observable triplet")
    fits = {}
    for mode in ("E", "M"):
        fits[mode] = A.fit_mode_to_data(p, mode, verbose=True)
    R["inverse"] = {m: dict(lam=f["lam"], b_Ca=f["b_Ca"], chi2=f["chi2"],
                            obs={k: float(v) for k, v in f["obs"].items()},
                            resid=f["resid"]) for m, f in fits.items()}
    # Likelihood ratio between the two single-mode hypotheses
    dchi2 = fits["M"]["chi2"] - fits["E"]["chi2"]
    R["inverse"]["delta_chi2_M_minus_E"] = float(dchi2)
    print(f"    Delta chi2 (M - E) = {dchi2:.2f}")

    tgt = {d["key"]: d for d in A.LQVS}
    fig = plt.figure(figsize=(7.1, 3.0))
    gs = gridspec.GridSpec(1, 2, figure=fig, wspace=0.34,
                           width_ratios=[1.35, 1.0])
    ax = fig.add_subplot(gs[0, 0])
    keys = A.LQVS_PRIMARY + ["PDH", "pyruvate", "mito_mass", "firing"]
    xpos = np.arange(len(keys))
    for k_i, k in enumerate(keys):
        d = tgt[k]
        ax.plot([k_i, k_i], [d["lo"], d["hi"]], color=C_D, lw=4, alpha=0.30,
                solid_capstyle="butt")
        ax.plot(k_i, d["value"], "D", color=C_D, ms=5,
                label="human data" if k_i == 0 else None)
    for mode, c, mk in (("M", C_M, "o"), ("E", C_E, "s")):
        v = [fits[mode]["obs"][k] for k in keys]
        ax.plot(xpos, v, mk, color=c, ms=5, mfc="none", mew=1.4,
                label=f"Mode {mode} best fit")
    ax.axhline(1.0, color=C_K, lw=0.6, ls="--")
    ax.set_yscale("log")
    ax.set_xticks(xpos)
    ax.set_xticklabels(["complex I", "H$_2$O$_2$", "mtDNA", "PDH", "pyruvate",
                        "mito mass", "E/I ratio"], rotation=38, ha="right")
    ax.set_ylabel("ratio to control")
    ax.legend(loc="upper left", ncol=1)
    tag(ax, "a")
    ax.set_title("Only a lesion at the electrical node reproduces the data",
                 fontsize=8)

    ax = fig.add_subplot(gs[0, 1])
    lab = A.LQVS_PRIMARY
    w = 0.36
    for j, (mode, c) in enumerate((("M", C_M), ("E", C_E))):
        r = [fits[mode]["resid"][k] for k in lab]
        ax.bar(np.arange(len(lab)) + (j - 0.5) * w, r, w, color=c,
               label=f"Mode {mode}")
    ax.axhline(0, color=C_K, lw=0.7)
    for s in (-1.96, 1.96):
        ax.axhline(s, color=C_K, lw=0.6, ls=":")
    ax.set_xticks(np.arange(len(lab)))
    ax.set_xticklabels(["complex I", "H$_2$O$_2$", "mtDNA"], rotation=38,
                       ha="right")
    ax.set_ylabel("standardised residual ($\\sigma$)")
    ax.legend()
    tag(ax, "b")
    ax.set_title(f"$\\chi^2$: M = {fits['M']['chi2']:.0f}, "
                 f"E = {fits['E']['chi2']:.2f}", fontsize=8)
    fig.suptitle("Figure 2  Adjudication of causal direction by joint inversion "
                 "of three human observables", fontsize=8.5, y=1.07)
    save(fig, "figure2_inverse_problem")

    # =====================================================================
    print("[4] phenotype matching on measured complex I activity")
    target_act = tgt["C1_act"]["value"]
    mm = A.match_on_complexI(p, target_act=target_act)
    stat_keys = ["C1_act", "ATP", "Dpsi", "NADH", "ROS", "lactate", "pyruvate",
                 "PDH", "mtDNA"]
    dyn = {}
    static = {}
    for mode in ("M", "E"):
        y, q = mm[mode]["y"], mm[mode]["p"]
        static[mode] = {k: float(v) for k, v in
                        A.observables(y, q, p, y0).items()}
        dyn[mode] = discriminators(q, y, p, tau0)
    R["matched"] = dict(target_complexI=float(target_act),
                        lam={m: mm[m]["lam"] for m in "ME"},
                        attained={m: mm[m]["act"] for m in "ME"},
                        static=static, dynamic=dyn)

    # Identifiability: how far apart are the two modes in each observable,
    # relative to the reported measurement uncertainty?
    sep = {}
    for k in stat_keys:
        d = tgt.get(k)
        if d is None:
            continue
        s = max(abs(np.log(d["hi"] / d["value"])),
                abs(np.log(d["value"] / d["lo"]))) / 1.96
        sep[k] = float(abs(np.log(static["M"][k] / static["E"][k])) / s)
    R["matched"]["separation_sigma"] = sep
    print("    static separation (sigma): "
          + ", ".join(f"{k}={v:.2f}" for k, v in sep.items()))

    # =====================================================================
    print("[5] dynamic discriminators and directed information flow")
    sde = {}
    for mode in ("M", "E"):
        q, ya = acute(mm[mode]["p"], mm[mode]["y"])
        t0 = time.time()
        arr3 = A.simulate_sde(q, ya, T=NS["sde_T"], dt=0.005, sample_dt=0.25,
                              n_rep=NS["sde_rep"], seed=SEED + (mode == "E"))
        flow = A.directed_flow(arr3, nbins=4, n_surr=40 if not quick else 6,
                               seed=SEED + 7)
        print(f"    mode {mode}: TE(M->E)={flow['te_me_mean']:.4f} "
              f"TE(E->M)={flow['te_em_mean']:.4f} "
              f"asym={flow['asym']:+.3f}+-{flow['asym_sd']:.3f} "
              f"lag={flow['lag_mean']:+.2f} samples  [{time.time()-t0:.0f} s]")
        sde[mode] = dict(flow=flow, trace=arr3[:, :, 0])
    u = mannwhitneyu(sde["M"]["flow"]["te_me"] - sde["M"]["flow"]["te_em"],
                     sde["E"]["flow"]["te_me"] - sde["E"]["flow"]["te_em"])
    R["directed_flow"] = {m: {k: (float(v) if np.ndim(v) == 0 else
                                  np.asarray(v).tolist())
                              for k, v in sde[m]["flow"].items()}
                          for m in "ME"}
    R["directed_flow"]["mannwhitney_U"] = float(u.statistic)
    R["directed_flow"]["mannwhitney_p"] = float(u.pvalue)
    print(f"    Mann-Whitney U={u.statistic:.1f}, P={u.pvalue:.3g}")

    fig = plt.figure(figsize=(7.1, 4.8))
    gs = gridspec.GridSpec(2, 3, figure=fig, hspace=0.52, wspace=0.40)
    # (a,b) example stochastic traces
    for j, mode in enumerate(("M", "E")):
        ax = fig.add_subplot(gs[0, j])
        tr = sde[mode]["trace"]
        t = np.arange(tr.shape[0]) * 0.25
        z = lambda v: (v - v.mean()) / (v.std() + 1e-12)
        ax.plot(t, z(tr[:, 4]), color="#555599", lw=0.8,
                label=r"$|\Delta\psi_m|$")
        ax.plot(t, z(tr[:, 0]) - 5, color=(C_M if mode == "M" else C_E),
                lw=0.8, label="firing rate")
        ax.set_xlim(t[0], t[0] + 200)
        ax.set_yticks([])
        ax.set_xlabel("time (s)")
        ax.set_title(f"Mode {mode}: coupled fluctuations", fontsize=8)
        tag(ax, "ab"[j])
        if j == 0:
            ax.legend(loc="upper right", ncol=2)
    # (c) transfer entropy
    ax = fig.add_subplot(gs[0, 2])
    w = 0.34
    for j, mode in enumerate(("M", "E")):
        f = sde[mode]["flow"]
        ax.bar(j - w / 2, f["te_me_mean"], w, color="#555599",
               label=r"TE($\Delta\psi_m\!\to\!$rate)" if j == 0 else None)
        ax.bar(j + w / 2, f["te_em_mean"], w, color="#bb9955",
               label=r"TE(rate$\to\Delta\psi_m$)" if j == 0 else None)
    ax.set_xticks([0, 1]); ax.set_xticklabels(["Mode M", "Mode E"])
    ax.set_ylabel("effective TE (bits)")
    ax.ticklabel_format(axis="y", style="sci", scilimits=(-2, 2))
    ax.legend(loc="upper center")
    ax.set_title(f"Directed flow reverses (P = {u.pvalue:.1e})", fontsize=8)
    tag(ax, "c")
    # (d) PAI
    ax = fig.add_subplot(gs[1, 0])
    for j, mode in enumerate(("M", "E")):
        d = dyn[mode]
        ax.bar(j - w / 2, d["rho_M"], w, color="#117733",
               label="metabolic support" if j == 0 else None)
        ax.bar(j + w / 2, d["rho_E"], w, color="#882255",
               label="electrical silencing" if j == 0 else None)
    ax.axhline(0, color=C_K, lw=0.7)
    ax.set_xticks([0, 1]); ax.set_xticklabels(["Mode M", "Mode E"])
    ax.set_ylabel("fraction of stress relieved")
    ax.legend(loc="lower left")
    ax.set_title("Perturbation asymmetry", fontsize=8)
    tag(ax, "d")
    # (e) the three discriminators
    ax = fig.add_subplot(gs[1, 1])
    names = [r"$\Lambda$", "PAI", r"$\Theta$", "BCI"]
    keysd = ["Lambda", "PAI", "Theta", "BCI"]
    xx = np.arange(len(names))
    for j, (mode, c) in enumerate((("M", C_M), ("E", C_E))):
        ax.bar(xx + (j - 0.5) * w, [dyn[mode][k] for k in keysd], w,
               color=c, label=f"Mode {mode}")
    ax.axhline(0, color=C_K, lw=0.7)
    ax.set_xticks(xx); ax.set_xticklabels(names)
    ax.set_ylabel("discriminator value")
    ax.legend()
    ax.set_title("Dynamic discriminators separate the modes", fontsize=8)
    tag(ax, "e")
    # (f) static observables do not
    ax = fig.add_subplot(gs[1, 2])
    pretty = {"C1_act": "complex I", "ROS": "H$_2$O$_2$", "mtDNA": "mtDNA",
              "PDH": "PDH", "pyruvate": "pyruvate", "mito_mass": "mito mass",
              "firing": "E/I ratio"}
    ks = [k for k in ["C1_act", "PDH", "pyruvate", "mtDNA", "ROS"] if k in sep]
    xx = np.arange(len(ks))
    cols = ["#999999" if sep[k] < 1.96 else "#cc3311" for k in ks]
    ax.bar(xx, [sep[k] for k in ks], 0.6, color=cols)
    ax.axhline(1.96, color="#cc3311", lw=0.9, ls="--",
               label="detectable at $P<0.05$")
    ax.set_xticks(xx)
    ax.set_xticklabels([pretty.get(k, k) for k in ks], rotation=38, ha="right")
    ax.set_ylabel("mode separation ($\\sigma$)")
    ax.legend(loc="upper right")
    ax.set_title("Which static markers could separate them", fontsize=8)
    tag(ax, "f")
    fig.suptitle("Figure 3  Phenotype-matched lesions are separated by loop "
                 "dynamics but not by steady-state biochemistry",
                 fontsize=8.5, y=1.03)
    save(fig, "figure3_discriminators")

    # =====================================================================
    print(f"[6] Monte-Carlo classification over {NS['mc']} parameter draws")
    jitter_keys = ["q_Na", "q_Ca", "J_hk", "V_MCU", "K_MCU", "b_psi", "b_Ca",
                   "a_esa", "K_C1", "b_C1", "alpha_K", "alpha_Na", "f_leak",
                   "n_dam", "K_pmca", "f_rev"]
    rows = []
    saved = dict(M.P0)
    t0 = time.time()
    for it in range(NS["mc"]):
        fac = np.exp(rng.normal(0.0, 0.18, len(jitter_keys)))
        try:
            M.P0.clear(); M.P0.update(saved)
            for k, f in zip(jitter_keys, fac):
                M.P0[k] = saved[k] * f
            pi = M.calibrate(verbose=False)
            q0i, y0i = acute(pi, pi["_y0"])
            taui, _ = A.recovery_time(y0i, q0i)
            mmi = A.match_on_complexI(pi, target_act=target_act)
            for mode in ("M", "E"):
                if abs(mmi[mode]["act"] - target_act) > 0.08:
                    continue
                d = discriminators(mmi[mode]["p"], mmi[mode]["y"], pi, taui)
                rows.append(dict(it=it, mode=mode, **{k: float(v) for k, v
                                                      in d.items()}))
        except Exception:
            continue
    M.P0.clear(); M.P0.update(saved)
    print(f"    {len(rows)} usable samples in {time.time()-t0:.0f} s")

    labels = np.array([1 if r["mode"] == "M" else 0 for r in rows])
    feats = np.array([[r["Lambda"], r["PAI"], r["Theta"]] for r in rows])
    bci_all = np.array([r["BCI"] for r in rows])

    # Disjoint train/test split. The training half is used ONLY to fix the
    # sign and scale of each discriminator; the a-priori-weighted BCI is then
    # evaluated on the held-out half.
    idx = rng.permutation(len(rows))
    half = len(idx) // 2
    tr, te = idx[:half], idx[half:]

    def roc(score, lab):
        o = np.argsort(-score)
        lab = lab[o]
        tp = np.cumsum(lab); fp = np.cumsum(1 - lab)
        P, N = lab.sum(), (1 - lab).sum()
        tpr = np.r_[0, tp / max(P, 1)]; fpr = np.r_[0, fp / max(N, 1)]
        return fpr, tpr, float(np.trapezoid(tpr, fpr))

    signs = np.sign([np.mean(feats[tr][labels[tr] == 1, j])
                     - np.mean(feats[tr][labels[tr] == 0, j])
                     for j in range(3)])
    mu = feats[tr].mean(0); sd = feats[tr].std(0) + 1e-12
    comp_te = (((feats[te] - mu) / sd) * signs).mean(1)
    fpr_c, tpr_c, auc_c = roc(comp_te, labels[te])
    aucs = {}
    for j, nm in enumerate(["Lambda", "PAI", "Theta"]):
        aucs[nm] = roc(feats[te][:, j] * signs[j], labels[te])[2]
    _, _, auc_bci = roc(bci_all[te], labels[te])
    uu = mannwhitneyu(bci_all[labels == 1], bci_all[labels == 0])
    R["monte_carlo"] = dict(
        n_draws=NS["mc"], n_samples=len(rows), jitter_sd_log=0.18,
        jitter_keys=jitter_keys, signs=signs.tolist(),
        auc_single=aucs, auc_composite_heldout=auc_c, auc_bci_heldout=auc_bci,
        bci_M=[float(v) for v in bci_all[labels == 1]],
        bci_E=[float(v) for v in bci_all[labels == 0]],
        mannwhitney_U=float(uu.statistic), mannwhitney_p=float(uu.pvalue),
        rows=rows)
    print(f"    held-out AUC: composite={auc_c:.3f}, BCI={auc_bci:.3f}, "
          + ", ".join(f"{k}={v:.3f}" for k, v in aucs.items()))
    print(f"    BCI Mann-Whitney P = {uu.pvalue:.3g}")

    # =====================================================================
    print(f"[7] closure-time analysis ({NS['clos']} time points)")
    times = np.unique(np.round(np.geomspace(5.0, 6000.0, NS["clos"])))
    clos = {}
    for mode in ("M", "E"):
        q = M.with_lesion(p, mode, mm[mode]["lam"], damage_on=1.0)
        sol = solve_ivp(M.rhs, (0.0, times[-1] * 1.05), y0, args=(q,),
                        t_eval=times, method="LSODA", rtol=1e-8, atol=1e-11)
        seq = []
        for i in range(sol.y.shape[1]):
            yi = sol.y[:, i]
            qf = dict(q); qf["damage_on"] = 0.0
            try:
                g = A.loop_gains(yi, qf)
                tau, _ = A.recovery_time(yi, qf)
                pa = A.perturbation_asymmetry(q, yi, p)
                seq.append(dict(t=float(times[i]),
                                Lambda=float(np.log10(max(g["loop"], 1e-12))),
                                Theta=float(np.log10(tau0 / max(tau, 1e-12))),
                                PAI=pa["pai"],
                                BCI=A.bci(np.log10(max(g["loop"], 1e-12)),
                                          pa["pai"],
                                          np.log10(tau0 / max(tau, 1e-12))),
                                C1=float((1 - qf["lam_M"]) * yi[8] / y0[8]),
                                ROS=float(yi[7] / y0[7]),
                                ATP=float(yi[6] / y0[6])))
            except Exception:
                continue
        clos[mode] = seq
    R["closure"] = clos
    tt = np.array([s["t"] for s in clos["M"]])
    bm = np.array([s["BCI"] for s in clos["M"]])
    be = np.array([s["BCI"] for s in clos["E"]])
    gap = np.abs(bm - be)
    i_half = np.where(gap < 0.5 * gap.max())[0]
    tau_c = float(tt[i_half[0]]) if len(i_half) and i_half[0] > 0 else float("nan")
    R["closure_time_s"] = tau_c
    print(f"    BCI separation falls below half-maximum at t = {tau_c:.0f} s")

    fig = plt.figure(figsize=(7.1, 2.6))
    gs = gridspec.GridSpec(1, 3, figure=fig, wspace=0.40)
    ax = fig.add_subplot(gs[0, 0])
    for mode, c in (("M", C_M), ("E", C_E)):
        s = clos[mode]
        ax.semilogx([v["t"] for v in s], [v["C1"] for v in s], color=c,
                    label=f"Mode {mode}")
        ax.semilogx([v["t"] for v in s], [v["ROS"] for v in s], color=c,
                    ls="--", lw=1.0)
    ax.axhline(target_act, color=C_D, lw=0.8, ls=":")
    ax.set_xlabel("time since lesion onset (s)")
    ax.set_ylabel("ratio to control")
    ax.set_title("Convergence of biochemistry\n(solid: complex I, dashed: ROS)",
                 fontsize=8)
    ax.legend(); tag(ax, "a")
    ax = fig.add_subplot(gs[0, 1])
    for mode, c in (("M", C_M), ("E", C_E)):
        s = clos[mode]
        ax.semilogx([v["t"] for v in s], [v["BCI"] for v in s], color=c,
                    label=f"Mode {mode}")
    ax.axhline(0, color=C_K, lw=0.7)
    ax.set_xlabel("time since lesion onset (s)")
    ax.set_ylabel("BCI")
    ax.set_title("Dynamic discriminability persists", fontsize=8)
    ax.legend(); tag(ax, "b")
    ax = fig.add_subplot(gs[0, 2])
    ax.semilogx(tt, gap, color="#333333")
    ax.set_xlabel("time since lesion onset (s)")
    ax.set_ylabel(r"$|\mathrm{BCI}_M - \mathrm{BCI}_E|$")
    ax.set_title("Identifiability window", fontsize=8)
    tag(ax, "c")
    fig.suptitle("Figure 4  Static phenotypes converge while the loop retains a "
                 "directional signature", fontsize=8.5, y=1.10)
    save(fig, "figure4_closure")

    # =====================================================================
    print("[8] ROC and index distribution")
    fig = plt.figure(figsize=(7.1, 2.5))
    gs = gridspec.GridSpec(1, 3, figure=fig, wspace=0.40)
    ax = fig.add_subplot(gs[0, 0])
    ax.plot(fpr_c, tpr_c, color="#1b4f9c",
            label=f"composite (AUC {auc_c:.3f})")
    f2, t2, _ = roc(bci_all[te], labels[te])
    ax.plot(f2, t2, color="#c2541a", ls="--",
            label=f"BCI, fixed weights (AUC {auc_bci:.3f})")
    ax.plot([0, 1], [0, 1], color=C_K, lw=0.7, ls=":")
    ax.set_xlabel("false-positive rate"); ax.set_ylabel("true-positive rate")
    ax.legend(loc="lower right")
    ax.set_title("Held-out classification", fontsize=8)
    tag(ax, "a")
    ax = fig.add_subplot(gs[0, 1])
    bins = np.linspace(min(bci_all.min(), -1), max(bci_all.max(), 1), 26)
    ax.hist(bci_all[labels == 1], bins=bins, color=C_M, alpha=0.70,
            label="Mode M")
    ax.hist(bci_all[labels == 0], bins=bins, color=C_E, alpha=0.70,
            label="Mode E")
    ax.axvline(0, color=C_K, lw=0.8, ls="--")
    ax.set_xlabel("BCI"); ax.set_ylabel("parameter draws")
    ax.legend(); tag(ax, "b")
    ax.set_title(f"$P$ = {uu.pvalue:.1e}", fontsize=8)
    ax = fig.add_subplot(gs[0, 2])
    nm = ["Lambda", "PAI", "Theta"]
    ax.barh(np.arange(3), [aucs[k] for k in nm], 0.55, color="#777777")
    ax.axvline(0.5, color=C_K, lw=0.7, ls=":")
    ax.set_yticks(np.arange(3))
    ax.set_yticklabels([r"$\Lambda$", "PAI", r"$\Theta$"])
    ax.set_xlim(0.4, 1.0); ax.set_xlabel("held-out AUC")
    ax.set_title("Single-discriminator power", fontsize=8)
    tag(ax, "c")
    fig.suptitle("Figure 5  Robustness of causal classification to parameter "
                 "uncertainty", fontsize=8.5, y=1.10)
    save(fig, "figure5_roc")

    # =====================================================================
    print(f"[9] variance-based sensitivity analysis (Saltelli, N={NS['sobol']})")
    sob_keys = ["b_Ca", "b_psi", "a_esa", "alpha_K", "q_Ca", "n_dam", "K_C1",
                "f_leak"]
    d = len(sob_keys)
    sampler = qmc.Sobol(d, scramble=True, seed=SEED)
    nb = NS["sobol"]
    Aq = sampler.random(nb); Bq = sampler.random(nb)
    lo = np.array([saved[k] * 0.70 for k in sob_keys])
    hi = np.array([saved[k] * 1.30 for k in sob_keys])
    scale = lambda U: lo + U * (hi - lo)

    def gfun(x):
        try:
            M.P0.clear(); M.P0.update(saved)
            for k, v in zip(sob_keys, x):
                M.P0[k] = float(v)
            pi = M.calibrate(verbose=False)
            q0i, y0i = acute(pi, pi["_y0"])
            taui, _ = A.recovery_time(y0i, q0i)
            mmi = A.match_on_complexI(pi, target_act=target_act)
            dM = discriminators(mmi["M"]["p"], mmi["M"]["y"], pi, taui)
            dE = discriminators(mmi["E"]["p"], mmi["E"]["y"], pi, taui)
            return dM["BCI"] - dE["BCI"]
        except Exception:
            return np.nan

    yA = np.array([gfun(scale(u)) for u in Aq])
    yB = np.array([gfun(scale(u)) for u in Bq])
    S1, ST = {}, {}
    ok = np.isfinite(yA) & np.isfinite(yB)
    varY = np.nanvar(np.r_[yA[ok], yB[ok]])
    for j, k in enumerate(sob_keys):
        Cq = Aq.copy(); Cq[:, j] = Bq[:, j]
        yC = np.array([gfun(scale(u)) for u in Cq])
        m = ok & np.isfinite(yC)
        if m.sum() < 4 or varY <= 0:
            S1[k], ST[k] = np.nan, np.nan
            continue
        S1[k] = float(np.mean(yB[m] * (yC[m] - yA[m])) / varY)
        ST[k] = float(np.mean((yA[m] - yC[m]) ** 2) / (2 * varY))
        print(f"    {k:<9s} S1={S1[k]:+.3f}  ST={ST[k]:+.3f}")
    M.P0.clear(); M.P0.update(saved)
    R["sobol"] = dict(keys=sob_keys, n_base=nb, range="+-30%",
                      S1=S1, ST=ST, var_discriminability=float(varY),
                      mean_gap=float(np.nanmean(np.r_[yA[ok], yB[ok]])))

    # =====================================================================
    print("[10] writing tables")
    import csv
    def w(name, header, rows_):
        pth = os.path.join(RES, name)
        with open(pth, "w", newline="", encoding="utf-8") as fh:
            writer = csv.writer(fh)
            writer.writerow(header)
            writer.writerows(rows_)
        print(f"    wrote results/{name}")

    w("table1_parameters.csv",
      ["parameter", "symbol", "value", "units", "description", "source"],
      [[k, M.PARAM_META[k][0], f"{p[k]:.6g}", M.PARAM_META[k][1],
        M.PARAM_META[k][2], M.PARAM_META[k][3]]
       for k in sorted(M.P0) if not k.startswith("_")])
    w("table2_control_state.csv", ["variable", "value", "target"],
      [[n, f"{float(v):.6g}", f"{M.TARGETS[n]:.6g}"]
       for n, v in zip(M.STATE_NAMES, y0)])
    w("table3_validation.csv",
      ["observable", "human_value", "human_lo", "human_hi", "model_modeE",
       "model_modeM", "source"],
      [[d["label"], f"{d['value']:.4g}", f"{d['lo']:.4g}", f"{d['hi']:.4g}",
        f"{fits['E']['obs'].get(d['key'], float('nan')):.4g}",
        f"{fits['M']['obs'].get(d['key'], float('nan')):.4g}",
        d["src"]] for d in A.LQVS])
    w("table4_discriminators.csv",
      ["quantity", "mode_M", "mode_E"],
      [[k, f"{dyn['M'][k]:.4g}", f"{dyn['E'][k]:.4g}"]
       for k in ["Lambda", "PAI", "Theta", "BCI", "loop", "g_me", "g_em",
                 "tau", "rho_M", "rho_E"]])
    w("table5_sobol.csv", ["parameter", "S1", "ST"],
      [[k, f"{S1[k]:.4f}", f"{ST[k]:.4f}"] for k in sob_keys])

    R["provenance"] = dict(
        seed=SEED, python=sys.version.split()[0], numpy=np.__version__,
        platform=platform.platform(), quick=bool(quick),
        runtime_s=round(time.time() - t_start, 1), sizes=NS)
    with open(os.path.join(RES, "results.json"), "w") as fh:
        json.dump(R, fh, indent=1, default=lambda o: (o.tolist() if hasattr(
            o, "tolist") else float(o)))
    print(f"    wrote results/results.json")
    print(f"\ndone in {time.time()-t_start:.0f} s")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    main(**vars(ap.parse_args()))
