"""Recompute the Monte-Carlo classification and the variance-based sensitivity
analysis with the censored relaxation time, and patch results.json in place."""
import json, os, time
import numpy as np
from scipy.stats import qmc, mannwhitneyu
import model as M, analysis as A
from run_all import acute, discriminators, RES, SEED

rng = np.random.default_rng(SEED)
R = json.load(open(os.path.join(RES, "results.json")))
p = M.calibrate(verbose=False)
q0a, y0a = acute(p, p["_y0"]); tau0, _ = A.recovery_time(y0a, q0a)
target_act = R["matched"]["target_complexI"]
saved = dict(M.P0)
print(f"tau0 = {tau0:.1f} s   target complex I = {target_act:.4f}")

# ---- Monte Carlo ---------------------------------------------------------
jk = R["monte_carlo"]["jitter_keys"]
rows = []
t0 = time.time()
for it in range(220):
    fac = np.exp(rng.normal(0.0, 0.18, len(jk)))
    try:
        M.P0.clear(); M.P0.update(saved)
        for k, f in zip(jk, fac): M.P0[k] = saved[k] * f
        pi = M.calibrate(verbose=False)
        qi, yi = acute(pi, pi["_y0"]); taui, _ = A.recovery_time(yi, qi)
        mmi = A.match_on_complexI(pi, target_act=target_act)
        for mode in ("M", "E"):
            if abs(mmi[mode]["act"] - target_act) > 0.08: continue
            d = discriminators(mmi[mode]["p"], mmi[mode]["y"], pi, taui)
            if not all(np.isfinite(list(d.values()))): continue
            rows.append(dict(it=it, mode=mode, **{k: float(v) for k, v in d.items()}))
    except Exception:
        continue
M.P0.clear(); M.P0.update(saved)
print(f"MC: {len(rows)} samples in {time.time()-t0:.0f} s")

lab = np.array([1 if r["mode"] == "M" else 0 for r in rows])
F = np.array([[r["Lambda"], r["PAI"], r["Theta"]] for r in rows])
bci = np.array([r["BCI"] for r in rows])
idx = rng.permutation(len(rows)); h = len(idx)//2; tr, te = idx[:h], idx[h:]

def roc(s, l):
    o = np.argsort(-s); l = l[o]
    tp = np.cumsum(l); fp = np.cumsum(1-l)
    return (np.r_[0, fp/max((1-l).sum(),1)], np.r_[0, tp/max(l.sum(),1)],
            float(np.trapezoid(np.r_[0, tp/max(l.sum(),1)], np.r_[0, fp/max((1-l).sum(),1)])))

signs = np.sign([F[tr][lab[tr]==1,j].mean() - F[tr][lab[tr]==0,j].mean() for j in range(3)])
mu, sd = F[tr].mean(0), F[tr].std(0)+1e-12
_,_,auc_c = roc((((F[te]-mu)/sd)*signs).mean(1), lab[te])
_,_,auc_b = roc(bci[te], lab[te])
aucs = {nm: roc(F[te][:,j]*signs[j], lab[te])[2] for j,nm in enumerate(["Lambda","PAI","Theta"])}
uu = mannwhitneyu(bci[lab==1], bci[lab==0])
print(f"held-out AUC: composite={auc_c:.3f} BCI={auc_b:.3f} " +
      ", ".join(f"{k}={v:.3f}" for k,v in aucs.items()) + f"  P={uu.pvalue:.3g}")
R["monte_carlo"].update(dict(n_draws=220, n_samples=len(rows), signs=signs.tolist(),
    auc_single=aucs, auc_composite_heldout=auc_c, auc_bci_heldout=auc_b,
    bci_M=[float(v) for v in bci[lab==1]], bci_E=[float(v) for v in bci[lab==0]],
    mannwhitney_U=float(uu.statistic), mannwhitney_p=float(uu.pvalue),
    median_BCI_M=float(np.median(bci[lab==1])), median_BCI_E=float(np.median(bci[lab==0])),
    rows=rows, tau_censoring_factor=A.TAU_CAP_FACTOR))

# ---- Sobol (n a power of two) -------------------------------------------
keys = R["sobol"]["keys"]; d = len(keys); nb = 64
S = qmc.Sobol(d, scramble=True, seed=SEED)
Aq, Bq = S.random(nb), S.random(nb)
lo = np.array([saved[k]*0.70 for k in keys]); hi = np.array([saved[k]*1.30 for k in keys])
sc = lambda U: lo + U*(hi-lo)

def g(x):
    try:
        M.P0.clear(); M.P0.update(saved)
        for k, v in zip(keys, x): M.P0[k] = float(v)
        pi = M.calibrate(verbose=False)
        qi, yi = acute(pi, pi["_y0"]); taui, _ = A.recovery_time(yi, qi)
        mmi = A.match_on_complexI(pi, target_act=target_act)
        dM = discriminators(mmi["M"]["p"], mmi["M"]["y"], pi, taui)
        dE = discriminators(mmi["E"]["p"], mmi["E"]["y"], pi, taui)
        v = dM["BCI"] - dE["BCI"]
        return float(v) if np.isfinite(v) else np.nan
    except Exception:
        return np.nan

t0 = time.time()
yA = np.array([g(sc(u)) for u in Aq]); yB = np.array([g(sc(u)) for u in Bq])
ok = np.isfinite(yA) & np.isfinite(yB)
varY = float(np.nanvar(np.r_[yA[ok], yB[ok]]))
S1, ST = {}, {}
for j, k in enumerate(keys):
    Cq = Aq.copy(); Cq[:, j] = Bq[:, j]
    yC = np.array([g(sc(u)) for u in Cq])
    m = ok & np.isfinite(yC)
    if m.sum() < 8 or varY <= 0: S1[k] = ST[k] = float("nan"); continue
    S1[k] = float(np.mean(yB[m]*(yC[m]-yA[m]))/varY)
    ST[k] = float(np.mean((yA[m]-yC[m])**2)/(2*varY))
    print(f"  {k:<9s} S1={S1[k]:+.3f} ST={ST[k]:+.3f}")
M.P0.clear(); M.P0.update(saved)
print(f"Sobol in {time.time()-t0:.0f} s; mean gap={np.nanmean(np.r_[yA[ok],yB[ok]]):+.3f}, var={varY:.4f}")
R["sobol"].update(dict(n_base=nb, S1=S1, ST=ST, var_discriminability=varY,
    mean_gap=float(np.nanmean(np.r_[yA[ok], yB[ok]])), n_valid=int(ok.sum())))
json.dump(R, open(os.path.join(RES, "results.json"), "w"), indent=1,
          default=lambda o: o.tolist() if hasattr(o, "tolist") else float(o))
with open(os.path.join(RES, "table5_sobol.csv"), "w") as fh:
    fh.write("parameter,S1,ST\n")
    for k in keys: fh.write(f"{k},{S1[k]:.4f},{ST[k]:.4f}\n")
print("patched results.json + table5")
