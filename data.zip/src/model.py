"""
Bidirectionally coupled neuronal excitability <-> mitochondrial bioenergetics model.

Core model definition, calibration to physiological control steady state, and
lesion injection at either the metabolic node (Mode M) or the electrical node
(Mode E).

All parameter values are either (i) taken from the published literature with the
source recorded in PARAM_SOURCES, or (ii) scaling constants fixed by calibration
to the control steady-state targets in TARGETS (themselves literature-derived).

State vector (10 variables):
    0  r      firing rate                           (Hz)
    1  Na     cytosolic Na+                         (mM)
    2  Cac    cytosolic Ca2+                        (uM)
    3  Cam    matrix Ca2+                           (uM)
    4  Dpsi   inner-membrane potential magnitude    (mV)
    5  NADH   matrix NADH                           (mM)
    6  ATP    cytosolic ATP                         (mM)
    7  H      matrix/cytosolic H2O2 pool            (uM)
    8  c1     functional complex I capacity         (fraction)
    9  G      reduced-glutathione scavenging capacity (fraction)
"""

import numpy as np
from scipy.optimize import fsolve, brentq
from scipy.integrate import solve_ivp

# ----------------------------------------------------------------------------
# Control steady-state targets (literature-derived; see PARAM_SOURCES)
# ----------------------------------------------------------------------------
TARGETS = dict(
    r=4.0,        # mean cortical pyramidal firing rate, Hz  (Attwell & Laughlin 2001)
    Na=10.0,      # cytosolic [Na+], mM
    Cac=0.10,     # resting cytosolic [Ca2+], uM
    Cam=0.20,     # resting matrix [Ca2+], uM
    Dpsi=150.0,   # |Delta psi_m|, mV   (Nicholls 2004; state-3/4 range 140-180)
    NADH=0.50,    # matrix NADH, mM (NAD_tot = 2.5 mM)
    ATP=2.50,     # cytosolic ATP, mM (A_tot = 2.6 mM -> ADP = 0.1 mM)
    H=0.010,      # steady H2O2, uM
    c1=0.95,      # functional complex I fraction
    G=0.95,       # reduced scavenging capacity fraction
)

NAD_TOT = 2.5     # mM
A_TOT = 2.6       # mM

P0 = dict(
    # --- electrical node -----------------------------------------------------
    tau_r=0.050,      # firing-rate adaptation time constant, s
    r_max=40.0,       # saturating firing rate, Hz
    theta=1.0,        # rate-function threshold (dimensionless drive)
    kappa=0.45,       # rate-function gain (dimensionless drive)
    D0=1.0,           # baseline excitatory drive (set by calibration)
    alpha_Na=0.015,   # depolarising drive per mM Na+ above reference
    Na_ref=10.0,
    alpha_H=0.80,     # ROS-dependent increase in excitability, per uM H2O2
    alpha_K=2.00,     # K_ATP-mediated hyperpolarising drive, max
    K_KATP=1.80,      # ATP (mM) at half-maximal K_ATP opening
    n_KATP=4.0,

    # --- Na+ handling --------------------------------------------------------
    q_Na=0.023,       # Na+ load per spike, mM/spike (Attwell & Laughlin 2001;
                      # Harris & Attwell 2012 revised AP cost)
    L_Na=0.060,       # resting Na+ leak, mM/s
    V_pump=0.030,     # Na/K-ATPase Vmax, mM/s (set by calibration)
    K_Na=12.0,        # mM
    K_mATP=0.30,      # mM, ATP affinity of P-type ATPases

    # --- Ca2+ handling -------------------------------------------------------
    q_Ca=0.0060,      # Ca2+ load per spike, uM/spike
    L_Ca=0.0020,      # resting Ca2+ leak, uM/s
    k_ext=0.120,      # PMCA/NCX extrusion Vmax, uM/s (set by calibration)
    K_pmca=0.50,      # uM; PMCA/NCX half-saturation, so Ca2+ clearance
                      # saturates as load rises (Brini & Carafoli 2009)
    V_MCU=0.800,      # MCU Vmax, uM/s
    K_MCU=0.800,      # uM (low-affinity uniporter)
    b_mcu=30.0,       # mV, voltage sensitivity of MCU
    V_NCLX=0.900,     # mitochondrial Ca2+ efflux rate, 1/s
    delta_m=0.150,    # matrix/cytosol Ca2+ volume-buffer ratio

    # --- substrate dehydrogenases -------------------------------------------
    V_DH=1.60,        # mM/s (set by calibration)
    a_Ca=2.50,        # Ca2+ activation of dehydrogenases, max fold
    K_DH=0.40,        # uM
    K_NAD=0.60,       # mM
    S_sub=1.0,        # substrate availability (rescue knob)
    a_esa=4.00,       # Ca2+ "each-step activation" of complex I and F1F0,
                      # max fold (Korzeniewski 2003 Biochem J 375:799)
    K_esa=0.50,       # uM

    # --- complex I / respiratory chain --------------------------------------
    V_C1=2.00,        # mM/s (set by calibration)
    K_C1=1.00,        # mM NADH (sub-saturating: leaves NADH headroom, so
                      # complex I inhibition raises NADH/NAD as observed)
    b_C1=12.0,        # mV, thermodynamic back-pressure sensitivity. Small
                      # b_C1 makes Delta psi_m strongly buffered and produces
                      # the threshold effect of respiratory-complex deficiency
                      # (Rossignol et al. 1999; Letellier et al. 1994)
    Dpsi_ref=150.0,   # mV reference
    n_H=9.0,          # H+ translocated per NADH (complexes I+III+IV)

    # --- ATP synthase / leak ------------------------------------------------
    V_F1=3.00,        # mM/s (set by calibration)
    K_F1=130.0,       # mV
    h_F1=6.0,
    K_ADP=0.080,      # mM
    g_leak=0.015,     # proton-leak conductance (set by calibration)
    b_leak=35.0,      # mV
    C_mito=1.80,      # effective inner-membrane capacitance, mV/(mM/s)/s

    # --- ATP budget ----------------------------------------------------------
    gamma_atp=1.0,
    J_hk=0.0180,      # housekeeping ATP demand, mM/s (~25% of total;
                      # Attwell & Laughlin 2001)
    k_ca_atp=0.025,   # ATP cost coefficient of Ca2+ extrusion

    # --- ROS production / scavenging ----------------------------------------
    V_ros=0.0040,     # uM/s basal (set by calibration)
    b_Ca=20.0,        # Ca2+ amplification of ROS, max fold
    K_ros=1.00,       # uM (Hill-2, above the resting operating point)
    b_psi=25.0,       # mV; e-fold ROS per b_psi mV  (Gauthier et al. 2013:
                      # complex III ROS rises exponentially with Dpsi)
    f_rev=0.60,       # weight of NADH-dependent (reverse-flow) complex I ROS
    k_scav=0.420,     # 1/s (set by calibration)

    # --- slow damage / repair loop ------------------------------------------
    # Written as relaxation toward a ROS-dependent set point, so that the only
    # free quantities are a time constant and a half-damage ROS level.
    tau_c1=300.0,     # complex I proteostatic time constant, s
    n_dam=4.0,        # cooperativity of cumulative oxidative inactivation
    n_G=2.0,          # cooperativity of scavenging-capacity depletion
    H_half=0.19,      # H2O2 (uM) at which steady c1 falls to 0.5 (set by calib.)
    tau_G=60.0,       # scavenging-capacity recovery time constant, s
    HG_half=0.19,     # H2O2 (uM) at which steady G falls to 0.5 (set by calib.)
    f_leak=0.20,      # proton leak as a fraction of total H+ pumping
                      # (Rolfe & Brand 1997: 20-25% of resting respiration)

    # --- lesion / perturbation knobs ----------------------------------------
    lam_M=0.0,        # Mode M lesion: fractional loss of complex I capacity
    lam_E=0.0,        # Mode E lesion: fractional excess excitatory drive
    blockNa=0.0,      # TTX-like fractional block of activity-driven Na+/Ca2+ load
    rescue=0.0,       # metabolic support: substrate + antioxidant, 0..1
    damage_on=1.0,    # enable (1) or freeze (0) the slow damage loop
)

PARAM_SOURCES = {
    "r": "Mean cortical firing rate 4 Hz (Attwell & Laughlin 2001 JCBFM 21:1133)",
    "q_Na": "Na+ entry per action potential; revised cortical AP budget "
            "(Attwell & Laughlin 2001; Harris & Attwell 2012 J Neurosci 32:356; "
            "Harris et al. 2012 Neuron 75:762; Howarth et al. 2012 JCBFM 32:1222)",
    "J_hk": "Non-signalling ('housekeeping') ATP use ~25% of total grey-matter "
            "ATP (Attwell & Laughlin 2001; Howarth et al. 2012 JCBFM 32:1222)",
    "Dpsi": "Delta psi_m 140-180 mV in brain mitochondria (Nicholls 2004 Aging Cell 3:35)",
    "b_psi": "Exponential dependence of complex III ROS on Delta psi_m "
             "(Gauthier et al. 2013 Biophys J 105:1045)",
    "a_Ca": "Ca2+ activation of matrix dehydrogenases (Cortassa et al. 2003 Biophys J 84:2734; "
            "Wei et al. 2011 Biophys J 100:2894)",
    "K_F1 / h_F1": "Steep Delta psi_m dependence of F1F0 flux "
                   "(Korzeniewski & Zoladz 2001 Biophys Chem 92:17)",
    "k_scav": "GSH/Trx/SOD scavenging network lumped as first order "
              "(Kembro et al. 2013 Biophys J 104:332)",
    "NAD_TOT / A_TOT": "Matrix NAD(H) and adenine nucleotide pool sizes "
                       "(Nazaret et al. 2009 J Theor Biol 258:455)",
    "k_dam": "ROS-mediated inactivation of complex I; calibrated so that the "
             "chronic Mode E attractor reproduces the complex I activity ratio "
             "reported by Giulivi et al. 2010 JAMA 304:2389",
}

PARAM_META = {
    # Electrical node
    "tau_r": ("\\tau_r", "s", "Firing-rate adaptation time constant", "Rate-model cortical timescale"),
    "r_max": ("r_{\\max}", "Hz", "Maximum cortical pyramidal firing rate", "Physiological pyramidal neuron range"),
    "theta": ("\\theta", "dimensionless", "Sigmoidal firing threshold", "Model rate-transfer baseline"),
    "kappa": ("\\kappa", "dimensionless", "Sigmoidal firing gain", "Model rate-transfer baseline"),
    "D0": ("D_0", "dimensionless", "Baseline excitatory drive", "Closed-form calibration (firing balance)"),
    "alpha_Na": ("\\alpha_{\\mathrm{Na}}", "mM^{-1}", "Depolarising drive per mM cytosolic Na+", "Model electrical-metabolic destabilising coupling"),
    "Na_ref": ("[\\mathrm{Na}^+]_{\\mathrm{ref}}", "mM", "Reference resting cytosolic [Na+]", "Physiological cortical neuron baseline"),
    "alpha_H": ("\\alpha_H", "\\mu M^{-1}", "ROS-dependent excitability gain", "Model redox-excitability coupling"),
    "alpha_K": ("\\alpha_K", "dimensionless", "Maximal K_ATP hyperpolarising drive", "Model metabolic stabilising feedback"),
    "K_KATP": ("K_K", "mM", "Half-maximal [ATP] for K_ATP opening", "Model K_ATP channel sensitivity"),
    "n_KATP": ("n_K", "dimensionless", "Hill cooperativity of K_ATP gating", "Tetrameric K_ATP stoichiometry"),
    # Na+ handling
    "q_Na": ("q_{\\mathrm{Na}}", "mM\\cdot spike^{-1}", "Cytosolic Na+ load per action potential", "Revised AP energy budget (Attwell & Laughlin 2001; Harris et al. 2012; Howarth et al. 2012)"),
    "L_Na": ("L_{\\mathrm{Na}}", "mM\\cdot s^{-1}", "Resting background Na+ leak", "Resting neuronal ion balance"),
    "V_pump": ("V_{\\mathrm{pump}}", "mM\\cdot s^{-1}", "Maximal Na+/K+-ATPase flux", "Closed-form calibration (Na+ balance)"),
    "K_Na": ("K_{\\mathrm{Na}}", "mM", "Half-maximal [Na+] for Na+/K+-ATPase", "Physiological pump affinity"),
    "K_mATP": ("K_A", "mM", "Apparent [ATP] affinity of P-type ion pumps", "Model ATPase Michaelis constant"),
    # Ca2+ handling
    "q_Ca": ("q_{\\mathrm{Ca}}", "\\mu M\\cdot spike^{-1}", "Cytosolic Ca2+ load per action potential", "Activity-dependent Ca2+ influx"),
    "L_Ca": ("L_{\\mathrm{Ca}}", "\\mu M\\cdot s^{-1}", "Resting background Ca2+ leak", "Resting cytosolic Ca2+ balance"),
    "k_ext": ("k_{\\mathrm{ext}}", "\\mu M\\cdot s^{-1}", "Maximal plasmalemmal Ca2+ extrusion flux", "Closed-form calibration (cytosolic Ca2+ balance)"),
    "K_pmca": ("K_P", "\\mu M", "PMCA/NCX half-saturation [Ca2+]", "Saturable clearance (Brini & Carafoli 2009)"),
    "V_MCU": ("V_{\\mathrm{MCU}}", "\\mu M\\cdot s^{-1}", "Maximal mitochondrial Ca2+ uniporter uptake", "Low-affinity uniporter kinetics (Wei et al. 2011)"),
    "K_MCU": ("K_{\\mathrm{MCU}}", "\\mu M", "Half-maximal cytosolic [Ca2+] for MCU", "Low-affinity MCU kinetics"),
    "b_mcu": ("b_{\\mathrm{MCU}}", "mV", "Voltage sensitivity scale of MCU uptake", "Electrochemical MCU driving scale"),
    "V_NCLX": ("V_{\\mathrm{NCLX}}", "s^{-1}", "Mitochondrial Na+/Ca2+ exchanger efflux rate", "Closed-form calibration (matrix Ca2+ balance)"),
    "delta_m": ("\\delta_{\\mathrm{m}}", "dimensionless", "Matrix-to-cytosol effective Ca2+ volume-buffering ratio", "Mitochondrial Ca2+ buffering (Wei et al. 2011)"),
    # Substrate dehydrogenases and parallel activation
    "V_DH": ("V_{\\mathrm{DH}}", "mM\\cdot s^{-1}", "Maximal matrix dehydrogenase flux", "Closed-form calibration (NADH balance)"),
    "a_Ca": ("a_{\\mathrm{Ca}}", "dimensionless", "Maximal fold Ca2+ activation of dehydrogenases", "Cortassa et al. 2003; Wei et al. 2011"),
    "K_DH": ("K_{\\mathrm{DH}}", "\\mu M", "Half-maximal matrix [Ca2+] for dehydrogenases", "Wei et al. 2011"),
    "K_NAD": ("K_{\\mathrm{NAD}}", "mM", "Half-maximal [NAD+] for dehydrogenase flux", "Nazaret et al. 2009"),
    "S_sub": ("S", "dimensionless", "Relative substrate availability (baseline = 1)", "Model substrate supply input"),
    "a_esa": ("a_{\\mathrm{ESA}}", "dimensionless", "Maximal fold Ca2+ each-step parallel activation", "Korzeniewski & Zoladz 2001; Korzeniewski 2003"),
    "K_esa": ("K_{\\mathrm{ESA}}", "\\mu M", "Half-maximal matrix [Ca2+] for parallel activation", "Model parallel-activation threshold"),
    # Complex I / respiratory chain
    "V_C1": ("V_{\\mathrm{C1}}", "mM\\cdot s^{-1}", "Maximal complex I electron flux", "Closed-form calibration (proton balance)"),
    "K_C1": ("K_{\\mathrm{C1}}", "mM", "Half-maximal [NADH] for complex I", "Sub-saturating affinity preserving NADH headroom"),
    "b_C1": ("b_{\\mathrm{C1}}", "mV", "Thermodynamic back-pressure scale on complex I", "Threshold behaviour (Letellier et al. 1994; Rossignol et al. 2003)"),
    "Dpsi_ref": ("\\Delta\\psi_0", "mV", "Reference resting inner-membrane potential magnitude", "Nicholls & Budd 2000; Nicholls 2004"),
    "n_H": ("n_H", "dimensionless", "Protons translocated per NADH oxidised", "Complexes I+III+IV stoichiometry"),
    # ATP synthase and proton leak
    "V_F1": ("V_{\\mathrm{F1}}", "mM\\cdot s^{-1}", "Maximal F1F0-ATP synthase flux", "Closed-form calibration (ATP balance)"),
    "K_F1": ("K_{\\mathrm{F1}}", "mV", "Half-maximal |Delta psi_m| for ATP synthase", "Korzeniewski & Zoladz 2001"),
    "h_F1": ("h", "dimensionless", "Voltage Hill exponent of ATP synthase", "Korzeniewski & Zoladz 2001"),
    "K_ADP": ("K_{\\mathrm{ADP}}", "mM", "Apparent [ADP] affinity of ATP synthase", "Model phosphorylation kinetics"),
    "g_leak": ("g_{\\mathrm{leak}}", "mM\\cdot s^{-1}", "Basal inner-membrane proton-leak prefactor", "Closed-form calibration (20% leak; Rolfe & Brand 1997; Rolfe & Brown 1997)"),
    "b_leak": ("b_{\\mathrm{leak}}", "mV", "Voltage exponential scale of proton leak", "Non-ohmic inner-membrane proton leak"),
    "C_mito": ("C_{\\mathrm{m}}^{-1}", "mV\\cdot mM^{-1}", "Inverse effective inner-membrane capacitance (1/C_m)", "Inner-membrane potential integration scale"),
    # ATP budget
    "gamma_atp": ("\\gamma_{\\mathrm{ATP}}", "dimensionless", "Stoichiometric ATP yield factor per F1F0 cycle", "Conserved phosphorylation stoichiometry"),
    "J_hk": ("J_{\\mathrm{hk}}", "mM\\cdot s^{-1}", "Non-signalling housekeeping ATP demand (~25%)", "Attwell & Laughlin 2001; Howarth et al. 2012"),
    "k_ca_atp": ("k_{\\mathrm{Ca}}", "mM\\cdot\\mu M^{-1}", "ATP cost coefficient of plasmalemmal Ca2+ extrusion", "P-type Ca2+-ATPase stoichiometry"),
    # ROS production and scavenging
    "V_ros": ("V_{\\mathrm{ros}}", "\\mu M\\cdot s^{-1}", "Basal mitochondrial H2O2 production rate", "Model resting redox baseline"),
    "b_Ca": ("b_{\\mathrm{Ca}}", "dimensionless", "Maximal matrix Ca2+ amplification of ROS", "Estimated in cohort inversion (25.1 in Mode E; baseline 20.0)"),
    "K_ros": ("K_{\\mathrm{ros}}", "\\mu M", "Half-maximal matrix [Ca2+] for ROS amplification", "Supra-resting Hill-2 ROS threshold"),
    "b_psi": ("b_\\psi", "mV", "Voltage exponential scale of complex III ROS", "Gauthier et al. 2013"),
    "f_rev": ("f_{\\mathrm{rev}}", "dimensionless", "NADH-dependent (reverse-electron-flow) ROS weight", "Aon et al. 2010; Kembro et al. 2013"),
    "k_scav": ("k_{\\mathrm{scav}}", "s^{-1}", "Lumped first-order GSH/Trx/SOD scavenging rate", "Closed-form calibration (ROS balance; Kembro et al. 2013)"),
    # Slow proteostatic loop
    "tau_c1": ("\\tau_{c1}", "s", "Compressed complex I proteostatic turnover time", "Separation-of-timescales model parameter"),
    "n_dam": ("n_d", "dimensionless", "Hill cooperativity of oxidative complex I inactivation", "Reproduces patient complex I loss at 2x ROS (Giulivi et al. 2010)"),
    "n_G": ("n_G", "dimensionless", "Hill cooperativity of scavenging-capacity depletion", "Model antioxidant depletion kinetics"),
    "H_half": ("H_c", "\\mu M", "Half-damage [H2O2] for complex I capacity", "Closed-form calibration (c1 = 0.95)"),
    "tau_G": ("\\tau_G", "s", "Compressed recovery time of scavenging capacity", "Separation-of-timescales model parameter"),
    "HG_half": ("H_G", "\\mu M", "Half-depletion [H2O2] for scavenging capacity", "Closed-form calibration (G = 0.95)"),
    "f_leak": ("f_{\\mathrm{leak}}", "dimensionless", "Resting proton-leak fraction of proton pumping", "Rolfe & Brand 1997; Rolfe & Brown 1997 (20%)"),
    # Lesion and perturbation knobs
    "lam_M": ("\\lambda_M", "dimensionless", "Mode M fractional loss of complex I capacity", "Primary respiratory lesion parameter (baseline 0)"),
    "lam_E": ("\\lambda_E", "dimensionless", "Mode E fractional excess excitatory drive", "Primary E/I drive lesion parameter (baseline 0)"),
    "blockNa": ("\\beta", "dimensionless", "Activity-dependent Na+/Ca2+ block (electrical probe)", "TTX-like silencing probe (0 baseline; 0.5 during probe)"),
    "rescue": ("\\text{rescue}", "dimensionless", "Metabolic support challenge (+45% S, +120% k_scav)", "Substrate + antioxidant probe (0 baseline; 1.0 during probe)"),
    "damage_on": ("\\text{damage\\_on}", "binary", "Slow proteostatic loop toggle (1 active, 0 frozen)", "Chronic (1) vs acute probe (0) switch"),
}

CALIB_KEYS = ["D0", "V_pump", "V_NCLX", "k_ext", "V_F1", "V_C1",
              "g_leak", "V_DH", "k_scav", "H_half", "HG_half"]
STATE_NAMES = ["r", "Na", "Cac", "Cam", "Dpsi", "NADH", "ATP", "H", "c1", "G"]


# ----------------------------------------------------------------------------
# Model right-hand side (vectorised over trailing axis)
# ----------------------------------------------------------------------------
def fluxes(y, p):
    """Return (dy/dt, flux dictionary). y may be shape (10,) or (10, R)."""
    r, Na, Cac, Cam, Dpsi, NADH, ATP, H, c1, G = y

    Na = np.maximum(Na, 1e-6)
    Cac = np.maximum(Cac, 1e-9)
    Cam = np.maximum(Cam, 1e-9)
    Dpsi = np.clip(Dpsi, 1.0, 260.0)
    NADH = np.clip(NADH, 1e-6, NAD_TOT - 1e-6)
    ATP = np.clip(ATP, 1e-6, A_TOT - 1e-6)
    H = np.maximum(H, 0.0)
    c1 = np.clip(c1, 1e-4, 1.0)
    G = np.clip(G, 1e-4, 1.0)

    ADP = A_TOT - ATP
    NAD = NAD_TOT - NADH
    f_act = 1.0 - p["blockNa"]          # activity-dependent load scaling
    S = p["S_sub"] * (1.0 + 0.45 * p["rescue"])
    scav = p["k_scav"] * (1.0 + 1.20 * p["rescue"])

    # --- electrical node: effective drive and rate ---------------------------
    sig_K = 1.0 / (1.0 + (ATP / p["K_KATP"]) ** p["n_KATP"])
    D = (p["D0"] * (1.0 + p["lam_E"])
         + p["alpha_Na"] * (Na - p["Na_ref"])
         + p["alpha_H"] * H
         - p["alpha_K"] * sig_K)
    r_inf = p["r_max"] / (1.0 + np.exp(-(D - p["theta"]) / p["kappa"]))
    dr = (r_inf - r) / p["tau_r"]

    # --- Na+ ------------------------------------------------------------------
    J_pump = (p["V_pump"]
              * Na ** 3 / (Na ** 3 + p["K_Na"] ** 3)
              * ATP / (ATP + p["K_mATP"]))
    dNa = p["q_Na"] * r * f_act + p["L_Na"] - 3.0 * J_pump

    # --- Ca2+ -----------------------------------------------------------------
    J_ext = p["k_ext"] * Cac / (Cac + p["K_pmca"]) * ATP / (ATP + p["K_mATP"])
    J_MCU = (p["V_MCU"] * Cac ** 2 / (Cac ** 2 + p["K_MCU"] ** 2)
             * np.exp((Dpsi - p["Dpsi_ref"]) / p["b_mcu"]))
    J_NCLX = p["V_NCLX"] * Cam
    dCac = p["q_Ca"] * r * f_act + p["L_Ca"] - J_ext - J_MCU + J_NCLX
    dCam = p["delta_m"] * (J_MCU - J_NCLX)

    # --- substrate supply and complex I -------------------------------------
    J_DH = (p["V_DH"] * S
            * (1.0 + p["a_Ca"] * Cam / (Cam + p["K_DH"]))
            * NAD / (NAD + p["K_NAD"]))
    esa = 1.0 + p["a_esa"] * Cam / (Cam + p["K_esa"])
    cap_C1 = p["V_C1"] * (1.0 - p["lam_M"]) * c1 * esa
    J_C1 = (cap_C1 * NADH / (NADH + p["K_C1"])
            * np.exp(-(Dpsi - p["Dpsi_ref"]) / p["b_C1"]))
    dNADH = J_DH - J_C1

    # --- Delta psi_m ----------------------------------------------------------
    J_F1 = (p["V_F1"] * esa
            * Dpsi ** p["h_F1"] / (Dpsi ** p["h_F1"] + p["K_F1"] ** p["h_F1"])
            * ADP / (ADP + p["K_ADP"]))
    J_leak = p["g_leak"] * (np.exp(Dpsi / p["b_leak"]) - 1.0)
    dDpsi = p["C_mito"] * (p["n_H"] * J_C1 - 3.0 * J_F1 - J_leak - 2.0 * J_MCU)

    # --- ATP ------------------------------------------------------------------
    dATP = (p["gamma_atp"] * J_F1 - J_pump - p["k_ca_atp"] * J_ext - p["J_hk"])

    # --- ROS ------------------------------------------------------------------
    P_ROS = (p["V_ros"]
             * (1.0 + p["b_Ca"] * Cam ** 2 / (Cam ** 2 + p["K_ros"] ** 2))
             * np.exp((Dpsi - p["Dpsi_ref"]) / p["b_psi"])
             * (1.0 - p["f_rev"] + p["f_rev"] * (NADH / TARGETS["NADH"])))
    S_ROS = scav * G * H
    dH = P_ROS - S_ROS

    # --- slow damage / repair -------------------------------------------------
    dc1 = (p["damage_on"] / p["tau_c1"]
           * ((1.0 - c1) - (H / p["H_half"]) ** p["n_dam"] * c1))
    dG = (p["damage_on"] / p["tau_G"]
          * ((1.0 - G) - (H / p["HG_half"]) ** p["n_G"] * G))

    dy = np.array([dr, dNa, dCac, dCam, dDpsi, dNADH, dATP, dH, dc1, dG])
    fl = dict(esa=esa, J_pump=J_pump, J_ext=J_ext, J_MCU=J_MCU, J_NCLX=J_NCLX,
              J_DH=J_DH, J_C1=J_C1, J_F1=J_F1, J_leak=J_leak,
              P_ROS=P_ROS, S_ROS=S_ROS, sig_K=sig_K, D=D, r_inf=r_inf,
              cap_C1=cap_C1, ADP=ADP)
    return dy, fl


def rhs(t, y, p):
    return fluxes(np.asarray(y, dtype=float), p)[0]


def slow_setpoints(H, p):
    """Steady-state values of the slow proteostatic variables for a given ROS
    level. Eliminating them analytically keeps the chronic attractor inside the
    physical interval (0, 1], which an unconstrained solver does not."""
    c1 = 1.0 / (1.0 + (np.maximum(H, 0.0) / p["H_half"]) ** p["n_dam"])
    G = 1.0 / (1.0 + (np.maximum(H, 0.0) / p["HG_half"]) ** p["n_G"])
    return c1, G


def steady_state(p, y0=None, strict=True, fast=False):
    """Locate a steady state by root finding, with an integration fallback.

    When the slow damage loop is active the slow variables are substituted from
    slow_setpoints, reducing the problem to eight equations and guaranteeing
    0 < c1, G <= 1.
    """
    if y0 is None:
        y0 = np.array([TARGETS[k] for k in STATE_NAMES])

    if p.get("damage_on", 1.0) >= 0.5:
        def resid8(z):
            H = z[7]
            c1, G = slow_setpoints(H, p)
            return rhs(0.0, np.concatenate([z, [c1, G]]), p)[:8]
        z, _, ok, _ = fsolve(resid8, y0[:8], full_output=True, xtol=1e-11)
        c1, G = slow_setpoints(z[7], p)
        y = np.concatenate([z, [c1, G]])
        res = np.max(np.abs(rhs(0.0, y, p)))
        if res > 1e-6 and not fast:
            tr = solve_ivp(rhs, (0.0, 20000.0), y0, args=(p,), method="LSODA",
                           rtol=1e-9, atol=1e-12)
            z2, _, _, _ = fsolve(resid8, tr.y[:8, -1], full_output=True, xtol=1e-11)
            c1, G = slow_setpoints(z2[7], p)
            y2 = np.concatenate([z2, [c1, G]])
            if np.max(np.abs(rhs(0.0, y2, p))) < res:
                y, res = y2, np.max(np.abs(rhs(0.0, y2, p)))
        if strict and res > 1e-5:
            raise RuntimeError(f"chronic steady state not converged, res={res:.2e}")
        return y

    sol = fsolve(lambda y: rhs(0.0, y, p), y0, full_output=True, xtol=1e-11)
    y, _, ok, _ = sol
    res = np.max(np.abs(rhs(0.0, y, p)))
    if (ok != 1 or res > 1e-6 or np.any(y[[1, 2, 3, 4, 5, 6]] <= 0)) and not fast:
        tr = solve_ivp(rhs, (0.0, 4000.0), y0, args=(p,), method="LSODA",
                       rtol=1e-8, atol=1e-11)
        y = tr.y[:, -1]
        sol2 = fsolve(lambda z: rhs(0.0, z, p), y, full_output=True, xtol=1e-11)
        if np.max(np.abs(rhs(0.0, sol2[0], p))) < res:
            y = sol2[0]
        res = np.max(np.abs(rhs(0.0, y, p)))
    if strict and res > 1e-5:
        raise RuntimeError(f"steady state not converged, residual={res:.2e}")
    return y


def jacobian(y, p, eps=1e-6):
    n = len(y)
    J = np.zeros((n, n))
    f0 = rhs(0.0, y, p)
    for j in range(n):
        dy = np.zeros(n)
        dy[j] = eps * max(1.0, abs(y[j]))
        J[:, j] = (rhs(0.0, y + dy, p) - f0) / dy[j]
    return J


# ----------------------------------------------------------------------------
# Calibration: fix scaling constants so the control steady state matches TARGETS
# ----------------------------------------------------------------------------
def calibrate(verbose=True):
    """Fix the scaling constants in closed form so that TARGETS is an exact
    steady state of the model.

    Each steady-state condition is solved analytically for one constant, in an
    order that makes the system triangular. No optimisation is involved, so the
    control state is reproduced exactly rather than approximately, and the
    proton budget is partitioned according to a measured leak fraction
    (p['f_leak']) rather than left to emerge from unconstrained parameters.
    """
    p = dict(P0)
    T = TARGETS
    r, Na, Cac, Cam, Dpsi = T["r"], T["Na"], T["Cac"], T["Cam"], T["Dpsi"]
    NADH, ATP, H, c1, G = T["NADH"], T["ATP"], T["H"], T["c1"], T["G"]
    ADP, NAD = A_TOT - ATP, NAD_TOT - NADH
    atp_occ = ATP / (ATP + p["K_mATP"])

    # (1) Na+ balance fixes the Na/K-ATPase Vmax.
    J_pump = (p["q_Na"] * r + p["L_Na"]) / 3.0
    p["V_pump"] = J_pump / (Na ** 3 / (Na ** 3 + p["K_Na"] ** 3) * atp_occ)

    # (2) Matrix Ca2+ balance fixes the mitochondrial efflux rate.
    J_MCU = p["V_MCU"] * Cac ** 2 / (Cac ** 2 + p["K_MCU"] ** 2)
    p["V_NCLX"] = J_MCU / Cam

    # (3) Cytosolic Ca2+ balance (with J_MCU = J_NCLX) fixes plasmalemmal efflux.
    J_ext = p["q_Ca"] * r + p["L_Ca"]
    p["k_ext"] = J_ext / (Cac / (Cac + p["K_pmca"]) * atp_occ)

    # (4) ATP balance fixes the F1F0 Vmax.
    J_F1 = J_pump + p["k_ca_atp"] * J_ext + p["J_hk"]
    esa = 1.0 + p["a_esa"] * Cam / (Cam + p["K_esa"])
    p["V_F1"] = J_F1 / (esa
                        * Dpsi ** p["h_F1"] / (Dpsi ** p["h_F1"] + p["K_F1"] ** p["h_F1"])
                        * ADP / (ADP + p["K_ADP"]))

    # (5) Proton balance with a prescribed leak fraction fixes complex I Vmax
    #     and the leak conductance.
    J_C1 = (3.0 * J_F1 + 2.0 * J_MCU) / ((1.0 - p["f_leak"]) * p["n_H"])
    p["V_C1"] = J_C1 / (c1 * esa * NADH / (NADH + p["K_C1"]))
    p["g_leak"] = (p["f_leak"] * p["n_H"] * J_C1) / (np.exp(Dpsi / p["b_leak"]) - 1.0)

    # (6) NADH balance fixes the dehydrogenase Vmax.
    p["V_DH"] = J_C1 / ((1.0 + p["a_Ca"] * Cam / (Cam + p["K_DH"]))
                        * NAD / (NAD + p["K_NAD"]))

    # (7) ROS balance fixes the lumped scavenging rate.
    P_ROS = (p["V_ros"] * (1.0 + p["b_Ca"] * Cam ** 2 / (Cam ** 2 + p["K_ros"] ** 2))
             * (1.0 - p["f_rev"] + p["f_rev"]))
    p["k_scav"] = P_ROS / (G * H)

    # (8) Slow-loop set points fix the half-damage ROS levels.
    p["H_half"] = H / ((1.0 - c1) / c1) ** (1.0 / p["n_dam"])
    p["HG_half"] = H / ((1.0 - G) / G) ** (1.0 / p["n_G"])

    # (9) Firing-rate balance fixes the baseline drive.
    sig_K = 1.0 / (1.0 + (ATP / p["K_KATP"]) ** p["n_KATP"])
    D_req = p["theta"] + p["kappa"] * np.log(r / (p["r_max"] - r))
    p["D0"] = D_req - p["alpha_H"] * H + p["alpha_K"] * sig_K

    for k in CALIB_KEYS:
        p[k] = float(p[k])

    ystar = np.array([T[k] for k in STATE_NAMES])
    d0 = rhs(0.0, ystar, p)
    res0 = np.max(np.abs(d0))
    if res0 > 1e-10:
        detail = ", ".join(f"d{n}={v:+.3e}" for n, v in zip(STATE_NAMES, d0))
        raise RuntimeError(f"closed-form calibration inconsistent "
                           f"({res0:.2e}): {detail}")

    y = steady_state(p, ystar)
    err = np.max(np.abs((y - ystar) / np.maximum(np.abs(ystar), 1e-9)))
    J = jacobian(ystar, p)
    lam_max = float(np.max(np.linalg.eigvals(J).real))
    if verbose:
        print(f"[calibrate] |dy/dt| at target = {res0:.2e} (exact)")
        print(f"[calibrate] relative deviation of recovered steady state = {err:.2e}")
        print(f"[calibrate] max Re(eigenvalue) = {lam_max:+.5f} 1/s "
              f"({'stable' if lam_max < 0 else 'UNSTABLE'})")
        print(f"[calibrate] proton budget: leak {p['f_leak']*100:.0f}%, "
              f"J_C1={J_C1:.4f}, J_F1={J_F1:.4f} mM/s")
        for k in CALIB_KEYS:
            print(f"            {k:<9s} {P0[k]:>11.5g} -> {p[k]:>11.5g}")
    if err > 1e-6 or lam_max >= 0:
        raise RuntimeError("control state not a stable attractor")
    p["_y0"] = y
    p["_lam_max"] = lam_max
    return p


# ----------------------------------------------------------------------------
# Lesion injection and phenotype matching
# ----------------------------------------------------------------------------
def with_lesion(p, mode, lam, damage_on=None):
    q = dict(p)
    q["lam_M"] = lam if mode == "M" else 0.0
    q["lam_E"] = lam if mode == "E" else 0.0
    if damage_on is not None:
        q["damage_on"] = float(damage_on)
    return q


def atp_deficit(p, mode, lam, damage_on, y0):
    q = with_lesion(p, mode, lam, damage_on)
    y = steady_state(q, y0, strict=False)
    return 1.0 - y[6] / TARGETS["ATP"], y


def match_lesions(p, target_deficit=0.20, damage_on=0.0, bracket=(1e-4, 0.95)):
    """Titrate lam_M and lam_E to the same fractional steady-state ATP deficit.

    This is the phenotype-matching step: it removes the trivial confound in
    which two lesions are distinguishable merely because they are of unequal
    severity.
    """
    y0 = p["_y0"]
    out = {}
    for mode in ("M", "E"):
        f = lambda lam: atp_deficit(p, mode, lam, damage_on, y0)[0] - target_deficit
        lo, hi = bracket
        flo, fhi = f(lo), f(hi)
        if flo * fhi > 0:
            hi = brentq(lambda l: f(l) + target_deficit - 1e-9, lo, hi) \
                if flo * fhi > 0 else hi
        lam = brentq(f, lo, hi, xtol=1e-9, rtol=1e-12)
        d, y = atp_deficit(p, mode, lam, damage_on, y0)
        out[mode] = dict(lam=float(lam), deficit=float(d), y=y)
    return out
